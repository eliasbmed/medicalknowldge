import type { User, InsertUser, MedicalFact, InsertMedicalFact, Vote, InsertVote, Newsletter, InsertNewsletter, FactWithVotes } from '@shared/schema';

export interface IStorage {
  // User management for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: any): Promise<User>;
  upsertUser(userData: UpsertUser): Promise<User>;

  // Enhanced medical facts
  getAllFacts(): Promise<FactWithVotes[]>;
  getFactById(id: number): Promise<MedicalFact | undefined>;
  createFact(fact: InsertMedicalFact): Promise<MedicalFact>;
  getFactsWithVotes(options?: any): Promise<FactWithVotes[]>;
  searchFacts(searchTerm: string, filters?: any): Promise<FactWithVotes[]>;

  // Voting
  createVote(vote: InsertVote): Promise<Vote>;
  getVotesByFactId(factId: number): Promise<Vote[]>;
  getUserVoteForFact(userId: string | null, factId: number): Promise<Vote | undefined>;

  // Newsletter
  subscribeNewsletter(newsletter: InsertNewsletter): Promise<Newsletter>;
  getNewsletterByEmail(email: string): Promise<Newsletter | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private facts: Map<number, MedicalFact>;
  private votes: Map<number, Vote>;
  private newsletters: Map<number, Newsletter>;
  private currentUserId: number;
  private currentFactId: number;
  private currentVoteId: number;
  private currentNewsletterId: number;

  constructor() {
    this.users = new Map();
    this.facts = new Map();
    this.votes = new Map();
    this.newsletters = new Map();
    this.currentUserId = 1;
    this.currentFactId = 1;
    this.currentVoteId = 1;
    this.currentNewsletterId = 1;
    this.initializeFacts();
  }

  private initializeFacts() {
    const essentialFacts = [
      {
        titleEn: "Give hydrocortisone 100mg IV immediately in suspected adrenal crisis",
        titleFr: "Donner hydrocortisone 100mg IV immédiatement en cas de crise surrénalienne suspectée",
        titleEs: "Dar hidrocortisona 100mg IV inmediatamente en crisis suprarrenal sospechada",
        detailsEn: "Adrenal crisis causes fatal shock within hours. Don't wait for cortisol results. Immediate hydrocortisone 100mg IV, then 50mg q6h, plus aggressive normal saline resuscitation.",
        detailsFr: "La crise surrénalienne cause un choc fatal en quelques heures. N'attendez pas les résultats de cortisol. Hydrocortisone immédiate 100mg IV, puis 50mg q6h, plus réanimation agressive au sérum physiologique.",
        detailsEs: "La crisis suprarrenal causa shock fatal en horas. No esperar resultados de cortisol. Hidrocortisona inmediata 100mg IV, luego 50mg c6h, más resucitación agresiva con solución salina normal.",
        category: "emergency",
        isApproved: true
      },
      {
        titleEn: "Widened mediastinum on chest X-ray = aortic dissection until proven otherwise",
        titleFr: "Médiastin élargi sur radiographie thoracique = dissection aortique jusqu'à preuve du contraire",
        titleEs: "Mediastino ensanchado en radiografía de tórax = disección aórtica hasta demostrar lo contrario",
        detailsEn: "Type A dissection involves ascending aorta (surgical emergency). Type B involves descending aorta (medical management). CT angiography is diagnostic. Never give thrombolytics if dissection suspected.",
        detailsFr: "Dissection type A implique aorte ascendante (urgence chirurgicale). Type B implique aorte descendante (gestion médicale). Angiographie CT est diagnostique. Ne jamais donner thrombolytiques si dissection suspectée.",
        detailsEs: "Disección tipo A involucra aorta ascendente (emergencia quirúrgica). Tipo B involucra aorta descendente (manejo médico). Angiografía TC es diagnóstica. Nunca dar trombolíticos si se sospecha disección.",
        category: "emergency",
        isApproved: true
      },
      {
        titleEn: "Never examine throat or agitate patient with suspected epiglottitis",
        titleFr: "Ne jamais examiner la gorge ou agiter un patient avec épiglottite suspectée",
        titleEs: "Nunca examinar garganta o agitar paciente con epiglotitis sospechada",
        detailsEn: "Epiglottitis can cause complete airway obstruction within minutes. 'Hot potato' voice + drooling + tripod positioning = epiglottitis. Keep child calm, prepare for emergency intubation.",
        detailsFr: "L'épiglottite peut causer obstruction complète voies aériennes en minutes. Voix 'patate chaude' + salivation + position tripode = épiglottite. Garder enfant calme, préparer intubation urgente.",
        detailsEs: "La epiglotitis puede causar obstrucción completa vías aéreas en minutos. Voz 'papa caliente' + babeo + posición trípode = epiglotitis. Mantener niño calmado, preparar intubación emergente.",
        category: "emergency",
        isApproved: true
      },
      {
        titleEn: "Crushing chest pain radiating to back = aortic dissection",
        titleFr: "Douleur thoracique écrasante irradiant vers le dos = dissection aortique",
        titleEs: "Dolor torácico aplastante irradiando hacia espalda = disección aórtica",
        detailsEn: "Classic presentation but only present in 50% of cases. Pulse differential between arms >20mmHg is highly suggestive. Immediate CT angiography, control blood pressure, avoid thrombolytics.",
        detailsFr: "Présentation classique mais présente seulement dans 50% des cas. Différence pouls entre bras >20mmHg très suggestive. Angiographie CT immédiate, contrôler tension artérielle, éviter thrombolytiques.",
        detailsEs: "Presentación clásica pero solo presente en 50% de casos. Diferencia de pulso entre brazos >20mmHg es muy sugestiva. Angiografía TC inmediata, controlar presión arterial, evitar trombolíticos.",
        category: "emergency",
        isApproved: true
      },
      {
        titleEn: "Testicular torsion: 'open book' manual detorsion saves the testis",
        titleFr: "Torsion testiculaire: détorsion manuelle 'livre ouvert' sauve le testicule",
        titleEs: "Torsión testicular: destorsión manual 'libro abierto' salva el testículo",
        detailsEn: "Rotate affected testis outward and upward like opening a book. Must be done within 6 hours. Sudden severe scrotal pain in adolescent = torsion until proven otherwise.",
        detailsFr: "Faire tourner testicule affecté vers l'extérieur et vers le haut comme ouvrir un livre. Doit être fait dans les 6 heures. Douleur scrotale sévère soudaine chez adolescent = torsion jusqu'à preuve du contraire.",
        detailsEs: "Rotar testículo afectado hacia afuera y arriba como abrir un libro. Debe hacerse en 6 horas. Dolor escrotal severo súbito en adolescente = torsión hasta demostrar lo contrario.",
        category: "emergency",
        isApproved: true
      },
      {
        titleEn: "Koplik spots precede measles rash by 24-48 hours",
        titleFr: "Les taches de Koplik précèdent l'éruption de rougeole de 24-48 heures",
        titleEs: "Las manchas de Koplik preceden al sarpullido del sarampión por 24-48 horas",
        detailsEn: "Small red spots with white centers on buccal mucosa. Highly specific for measles. Rash starts at hairline and spreads downward. Isolate patient immediately - highly contagious.",
        detailsFr: "Petites taches rouges avec centres blancs sur muqueuse buccale. Très spécifique pour rougeole. Éruption commence à ligne cheveux et se propage vers le bas. Isoler patient immédiatement - très contagieux.",
        detailsEs: "Pequeñas manchas rojas con centros blancos en mucosa bucal. Muy específico para sarampión. Sarpullido comienza en línea del cabello y se extiende hacia abajo. Aislar paciente inmediatamente - muy contagioso.",
        category: "infectious",
        isApproved: true
      },
      {
        titleEn: "Silent chest in asthma = impending respiratory arrest",
        titleFr: "Thorax silencieux dans l'asthme = arrêt respiratoire imminent",
        titleEs: "Tórax silencioso en asma = paro respiratorio inminente",
        detailsEn: "Absence of wheezing indicates severe airway obstruction, not improvement. Immediate intubation preparation. Give albuterol, ipratropium, methylprednisolone 125mg IV, magnesium 2g IV.",
        detailsFr: "Absence de sibilances indique obstruction sévère voies aériennes, pas amélioration. Préparation intubation immédiate. Donner albutérol, ipratropium, méthylprednisolone 125mg IV, magnésium 2g IV.",
        detailsEs: "Ausencia de sibilancias indica obstrucción severa vías aéreas, no mejoría. Preparación intubación inmediata. Dar albuterol, ipratropio, metilprednisolona 125mg IV, magnesio 2g IV.",
        category: "emergency",
        isApproved: true
      },
      {
        titleEn: "Waterhouse-Friderichsen syndrome = adrenal hemorrhage from meningococcemia",
        titleFr: "Syndrome de Waterhouse-Friderichsen = hémorragie surrénale de méningococcémie",
        titleEs: "Síndrome de Waterhouse-Friderichsen = hemorragia suprarrenal por meningococemia",
        detailsEn: "Petechial rash + shock + adrenal insufficiency. Bilateral adrenal hemorrhage from DIC. Give hydrocortisone immediately while treating meningococcal sepsis with ceftriaxone.",
        detailsFr: "Éruption pétéchiale + choc + insuffisance surrénale. Hémorragie surrénale bilatérale de CIVD. Donner hydrocortisone immédiatement pendant traitement sepsis méningococcique avec ceftriaxone.",
        detailsEs: "Erupción petequial + shock + insuficiencia suprarrenal. Hemorragia suprarrenal bilateral por CID. Dar hidrocortisona inmediatamente mientras se trata sepsis meningocócica con ceftriaxona.",
        category: "emergency",
        isApproved: true
      },
      {
        titleEn: "New LBBB with chest pain = STEMI equivalent",
        titleFr: "Nouveau BBG avec douleur thoracique = équivalent STEMI",
        titleEs: "Nuevo BRIHH con dolor torácico = equivalente STEMI",
        detailsEn: "Has same mortality as anterior STEMI. Sgarbossa criteria help identify acute MI in LBBB patients: concordant ST elevation ≥1mm, concordant ST depression ≥1mm in V1-V3, discordant ST elevation ≥5mm.",
        detailsFr: "A même mortalité que STEMI antérieur. Critères Sgarbossa aident identifier IM aigu chez patients BBG: élévation ST concordante ≥1mm, dépression ST concordante ≥1mm en V1-V3, élévation ST discordante ≥5mm.",
        detailsEs: "Tiene misma mortalidad que STEMI anterior. Criterios Sgarbossa ayudan identificar IM agudo en pacientes BRIHH: elevación ST concordante ≥1mm, depresión ST concordante ≥1mm en V1-V3, elevación ST discordante ≥5mm.",
        category: "cardiology",
        isApproved: true
      },
      {
        titleEn: "Janeway lesions are painless, Osler nodes are painful",
        titleFr: "Les lésions de Janeway sont indolores, les nodules d'Osler sont douloureux",
        titleEs: "Las lesiones de Janeway son indoloras, los nódulos de Osler son dolorosos",
        detailsEn: "Both indicate endocarditis. Janeway lesions: painless red macules on palms/soles. Osler nodes: painful nodules on finger pads. Also look for splinter hemorrhages, Roth spots.",
        detailsFr: "Les deux indiquent endocardite. Lésions Janeway: macules rouges indolores sur paumes/plantes. Nodules Osler: nodules douloureux sur pulpes doigts. Chercher aussi hémorragies en éclat, taches Roth.",
        detailsEs: "Ambos indican endocarditis. Lesiones Janeway: máculas rojas indoloras en palmas/plantas. Nódulos Osler: nódulos dolorosos en pulpejos dedos. Buscar también hemorragias astilla, manchas Roth.",
        category: "cardiology",
        isApproved: true
      }
    ];

    // Add all facts to storage
    essentialFacts.forEach(fact => {
      const newFact: MedicalFact = {
        ...fact,
        id: this.currentFactId++,
        createdAt: new Date()
      };
      this.facts.set(newFact.id, newFact);
    });

    // Add more comprehensive facts
    this.addComprehensiveFacts();
  }

  private addComprehensiveFacts() {
    const moreFacts = [
      {
        titleEn: "Hypercalcemic crisis >14 mg/dL causes coma and cardiac arrest",
        titleFr: "Crise hypercalcémique >14 mg/dL cause coma et arrêt cardiaque",
        titleEs: "Crisis hipercalcémica >14 mg/dL causa coma y paro cardíaco",
        detailsEn: "'Stones, bones, groans, psychiatric moans.' Immediate normal saline 200-300mL/hr, then furosemide, calcitonin 4 units/kg q12h. Avoid thiazides and calcium-containing IV fluids.",
        detailsFr: "'Pierres, os, gémissements, plaintes psychiatriques.' Sérum physiologique immédiat 200-300mL/h, puis furosémide, calcitonine 4 unités/kg q12h. Éviter thiazides et liquides IV contenant calcium.",
        detailsEs: "'Piedras, huesos, gemidos, quejas psiquiátricas.' Solución salina inmediata 200-300mL/h, luego furosemida, calcitonina 4 unidades/kg c12h. Evitar tiazidas y líquidos IV con calcio.",
        category: "emergency",
        isApproved: true
      },
      {
        titleEn: "McBurney's point tenderness = classic appendicitis location",
        titleFr: "Sensibilité point McBurney = localisation classique appendicite",
        titleEs: "Sensibilidad punto McBurney = ubicación clásica apendicitis",
        detailsEn: "Located 1/3 distance from anterior superior iliac spine to umbilicus. Rovsing sign: RLQ pain with LLQ palpation. Psoas sign: pain with hip extension. CT if diagnosis unclear.",
        detailsFr: "Situé 1/3 distance épine iliaque antéro-supérieure à ombilic. Signe Rovsing: douleur FID avec palpation FIG. Signe psoas: douleur avec extension hanche. TDM si diagnostic incertain.",
        detailsEs: "Ubicado 1/3 distancia espina ilíaca anterosuperior a ombligo. Signo Rovsing: dolor FID con palpación FII. Signo psoas: dolor con extensión cadera. TC si diagnóstico incierto.",
        category: "surgery",
        isApproved: true
      },
      {
        titleEn: "Tension pneumothorax: tracheal deviation is a late sign",
        titleFr: "Pneumothorax sous tension: déviation trachéale est signe tardif",
        titleEs: "Neumotórax a tensión: desviación traqueal es signo tardío",
        detailsEn: "Early signs: absent breath sounds, JVD, hypotension. Immediate needle decompression at 2nd ICS midclavicular line with 14-gauge needle, then chest tube placement.",
        detailsFr: "Signes précoces: bruits respiratoires absents, TJV, hypotension. Décompression immédiate aiguille 2e EIC ligne médioclaviculaire avec aiguille 14G, puis drain thoracique.",
        detailsEs: "Signos tempranos: ruidos respiratorios ausentes, TYV, hipotensión. Descompresión inmediata aguja 2° EIC línea medioclavicular con aguja 14G, luego tubo torácico.",
        category: "emergency",
        isApproved: true
      },
      {
        titleEn: "Battle sign and raccoon eyes indicate basilar skull fracture",
        titleFr: "Signe Battle et yeux au beurre noir indiquent fracture base crâne",
        titleEs: "Signo Battle y ojos de mapache indican fractura base cráneo",
        detailsEn: "Battle sign: bruising behind ear. Raccoon eyes: periorbital bruising. Both indicate basilar skull fracture. Associated with CSF leak, cranial nerve palsies. Never insert nasal tubes.",
        detailsFr: "Signe Battle: ecchymose derrière oreille. Yeux raton laveur: ecchymose périorbitaire. Indiquent fracture base crâne. Associé fuite LCR, paralysies nerfs crâniens. Jamais insérer tubes nasaux.",
        detailsEs: "Signo Battle: hematoma detrás oreja. Ojos mapache: hematoma periorbital. Indican fractura base cráneo. Asociado fuga LCR, parálisis nervios craneales. Nunca insertar tubos nasales.",
        category: "emergency",
        isApproved: true
      },
      {
        titleEn: "Beck triad: elevated JVP + muffled heart sounds + hypotension = cardiac tamponade",
        titleFr: "Triade Beck: PVJ élevée + bruits cardiaques étouffés + hypotension = tamponnade cardiaque",
        titleEs: "Tríada Beck: PVY elevada + ruidos cardíacos apagados + hipotensión = taponamiento cardíaco",
        detailsEn: "Pulsus paradoxus >20mmHg confirms diagnosis. Emergency pericardiocentesis via subxiphoid approach. Removing just 50mL can be lifesaving. Prepare for emergency thoracotomy.",
        detailsFr: "Pouls paradoxal >20mmHg confirme diagnostic. Péricardiocentèse urgente voie sous-xiphoïdienne. Retirer juste 50mL peut sauver vie. Préparer thoracotomie urgence.",
        detailsEs: "Pulso paradójico >20mmHg confirma diagnóstico. Pericardiocentesis emergente vía subxifoidea. Remover solo 50mL puede salvar vida. Preparar toracotomía emergencia.",
        category: "cardiology",
        isApproved: true
      }
    ];

    moreFacts.forEach(fact => {
      const newFact: MedicalFact = {
        ...fact,
        id: this.currentFactId++,
        createdAt: new Date()
      };
      this.facts.set(newFact.id, newFact);
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    for (const user of this.users.values()) {
      if (user.email === email) {
        return user;
      }
    }
    return undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const user: User = {
      ...insertUser,
      id: this.currentUserId++,
      createdAt: new Date()
    };
    this.users.set(user.id, user);
    return user;
  }

  async getAllFacts(): Promise<FactWithVotes[]> {
    return this.getFactsWithVotes();
  }

  async getFactById(id: number): Promise<MedicalFact | undefined> {
    return this.facts.get(id);
  }

  async createFact(insertFact: InsertMedicalFact): Promise<MedicalFact> {
    const fact: MedicalFact = {
      ...insertFact,
      id: this.currentFactId++,
      createdAt: new Date()
    };
    this.facts.set(fact.id, fact);
    return fact;
  }

  async getFactsWithVotes(): Promise<FactWithVotes[]> {
    const factsWithVotes: FactWithVotes[] = [];
    
    for (const fact of this.facts.values()) {
      const votes = Array.from(this.votes.values()).filter(vote => vote.factId === fact.id);
      const agreeVotes = votes.filter(vote => vote.voteType === 'agree').length;
      const disagreeVotes = votes.filter(vote => vote.voteType === 'disagree').length;
      
      factsWithVotes.push({
        ...fact,
        agreeVotes,
        disagreeVotes
      });
    }
    
    return factsWithVotes;
  }

  async createVote(insertVote: InsertVote): Promise<Vote> {
    const vote: Vote = {
      ...insertVote,
      id: this.currentVoteId++,
      createdAt: new Date()
    };
    this.votes.set(vote.id, vote);
    return vote;
  }

  async getVotesByFactId(factId: number): Promise<Vote[]> {
    return Array.from(this.votes.values()).filter(vote => vote.factId === factId);
  }

  async getUserVoteForFact(userId: number | null, factId: number): Promise<Vote | undefined> {
    if (!userId) return undefined;
    for (const vote of this.votes.values()) {
      if (vote.userId === userId && vote.factId === factId) {
        return vote;
      }
    }
    return undefined;
  }

  async subscribeNewsletter(insertNewsletter: InsertNewsletter): Promise<Newsletter> {
    const newsletter: Newsletter = {
      ...insertNewsletter,
      id: this.currentNewsletterId++,
      createdAt: new Date()
    };
    this.newsletters.set(newsletter.id, newsletter);
    return newsletter;
  }

  async getNewsletterByEmail(email: string): Promise<Newsletter | undefined> {
    for (const newsletter of this.newsletters.values()) {
      if (newsletter.email === email) {
        return newsletter;
      }
    }
    return undefined;
  }
}

import { DatabaseStorage } from "./database-storage";

export const storage = new MemStorage();