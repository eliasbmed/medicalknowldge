import {
  users,
  userProfiles,
  medicalFacts,
  votes,
  newsletters,
  bookmarks,
  comments,
  factFlags,
  achievements,
  userAchievements,
  quizQuestions,
  quizAttempts,
  readingProgress,
  type User,
  type UpsertUser,
  type MedicalFact,
  type InsertMedicalFact,
  type Vote,
  type InsertVote,
  type Newsletter,
  type InsertNewsletter,
  type UserProfile,
  type InsertUserProfile,
  type Bookmark,
  type InsertBookmark,
  type Comment,
  type InsertComment,
  type FactFlag,
  type InsertFactFlag,
  type Achievement,
  type QuizQuestion,
  type InsertQuizQuestion,
  type QuizAttempt,
  type InsertQuizAttempt,
  type ReadingProgress,
  type InsertReadingProgress,
  type FactWithVotes,
  type CommentWithUser,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, asc, count, sql, and, or, like, inArray } from "drizzle-orm";
import type { IStorage } from "./storage";

export class DatabaseStorage implements IStorage {
  // User management for Replit Auth
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(user: any): Promise<User> {
    const [newUser] = await db
      .insert(users)
      .values(user)
      .returning();
    return newUser;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // User profiles for gamification
  async getUserProfile(userId: string): Promise<UserProfile | undefined> {
    const [profile] = await db
      .select()
      .from(userProfiles)
      .where(eq(userProfiles.userId, userId));
    return profile;
  }

  async createUserProfile(profileData: InsertUserProfile): Promise<UserProfile> {
    const [profile] = await db
      .insert(userProfiles)
      .values(profileData)
      .returning();
    return profile;
  }

  async updateUserProfile(userId: string, updates: Partial<UserProfile>): Promise<UserProfile> {
    const [profile] = await db
      .update(userProfiles)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(userProfiles.userId, userId))
      .returning();
    return profile;
  }

  // Medical facts with enhanced queries
  async getAllFacts(): Promise<FactWithVotes[]> {
    return this.getFactsWithVotes();
  }

  async getFactById(id: number): Promise<MedicalFact | undefined> {
    const [fact] = await db
      .select()
      .from(medicalFacts)
      .where(eq(medicalFacts.id, id));
    return fact;
  }

  async createFact(fact: InsertMedicalFact): Promise<MedicalFact> {
    const [newFact] = await db
      .insert(medicalFacts)
      .values(fact)
      .returning();
    return newFact;
  }

  async getFactsWithVotes(
    options: {
      category?: string;
      search?: string;
      userId?: string;
      limit?: number;
      offset?: number;
      sortBy?: 'newest' | 'popular' | 'controversial';
      approved?: boolean;
    } = {}
  ): Promise<FactWithVotes[]> {
    const { category, search, userId, limit = 50, offset = 0, sortBy = 'newest', approved = true } = options;

    let query = db
      .select({
        id: medicalFacts.id,
        titleEn: medicalFacts.titleEn,
        titleFr: medicalFacts.titleFr,
        titleEs: medicalFacts.titleEs,
        detailsEn: medicalFacts.detailsEn,
        detailsFr: medicalFacts.detailsFr,
        detailsEs: medicalFacts.detailsEs,
        category: medicalFacts.category,
        createdAt: medicalFacts.createdAt,
        isApproved: medicalFacts.isApproved,
        agreeVotes: sql<number>`COALESCE(SUM(CASE WHEN ${votes.voteType} = 'agree' THEN 1 ELSE 0 END), 0)`,
        disagreeVotes: sql<number>`COALESCE(SUM(CASE WHEN ${votes.voteType} = 'disagree' THEN 1 ELSE 0 END), 0)`,
        commentsCount: sql<number>`0`,
        isBookmarked: userId 
          ? sql<boolean>`EXISTS(SELECT 1 FROM ${bookmarks} WHERE ${bookmarks.factId} = ${medicalFacts.id} AND ${bookmarks.userId} = ${userId})`
          : sql<boolean>`false`,
      })
      .from(medicalFacts)
      .leftJoin(votes, eq(votes.factId, medicalFacts.id))
      .groupBy(medicalFacts.id);

    if (approved !== undefined) {
      query = query.where(eq(medicalFacts.isApproved, approved));
    }

    if (category) {
      query = query.where(eq(medicalFacts.category, category));
    }

    if (search) {
      query = query.where(
        or(
          like(medicalFacts.titleEn, `%${search}%`),
          like(medicalFacts.titleFr, `%${search}%`),
          like(medicalFacts.titleEs, `%${search}%`),
          like(medicalFacts.detailsEn, `%${search}%`),
          like(medicalFacts.detailsFr, `%${search}%`),
          like(medicalFacts.detailsEs, `%${search}%`)
        )
      );
    }

    switch (sortBy) {
      case 'newest':
        query = query.orderBy(desc(medicalFacts.createdAt));
        break;
      case 'popular':
        query = query.orderBy(desc(sql`${sql`COALESCE(SUM(CASE WHEN ${votes.voteType} = 'agree' THEN 1 ELSE 0 END), 0)`}`));
        break;
      case 'controversial':
        query = query.orderBy(desc(sql`ABS(${sql`COALESCE(SUM(CASE WHEN ${votes.voteType} = 'agree' THEN 1 ELSE 0 END), 0)`} - ${sql`COALESCE(SUM(CASE WHEN ${votes.voteType} = 'disagree' THEN 1 ELSE 0 END), 0)`})`));
        break;
    }

    query = query.limit(limit).offset(offset);

    return await query;
  }

  async searchFacts(searchTerm: string, filters: { category?: string; userId?: string } = {}): Promise<FactWithVotes[]> {
    return this.getFactsWithVotes({
      search: searchTerm,
      category: filters.category,
      userId: filters.userId,
    });
  }

  // Voting system
  async createVote(vote: InsertVote): Promise<Vote> {
    const [newVote] = await db
      .insert(votes)
      .values(vote)
      .returning();

    // Update user profile stats if user is logged in
    if (vote.userId) {
      await this.incrementUserStats(vote.userId, { totalVotes: 1 });
    }

    return newVote;
  }

  async getVotesByFactId(factId: number): Promise<Vote[]> {
    return await db
      .select()
      .from(votes)
      .where(eq(votes.factId, factId));
  }

  async getUserVoteForFact(userId: string | null, factId: number): Promise<Vote | undefined> {
    if (!userId) return undefined;
    
    const [vote] = await db
      .select()
      .from(votes)
      .where(and(eq(votes.userId, userId), eq(votes.factId, factId)));
    
    return vote;
  }

  // Bookmarks
  async createBookmark(bookmark: InsertBookmark): Promise<Bookmark> {
    const [newBookmark] = await db
      .insert(bookmarks)
      .values(bookmark)
      .returning();
    return newBookmark;
  }

  async removeBookmark(userId: string, factId: number): Promise<void> {
    await db
      .delete(bookmarks)
      .where(and(eq(bookmarks.userId, userId), eq(bookmarks.factId, factId)));
  }

  async getUserBookmarks(userId: string): Promise<FactWithVotes[]> {
    const userBookmarksQuery = db
      .select({ factId: bookmarks.factId })
      .from(bookmarks)
      .where(eq(bookmarks.userId, userId));

    const factIds = await userBookmarksQuery;
    
    if (factIds.length === 0) return [];

    return this.getFactsWithVotes({
      userId,
    });
  }

  async isFactBookmarked(userId: string, factId: number): Promise<boolean> {
    const [bookmark] = await db
      .select()
      .from(bookmarks)
      .where(and(eq(bookmarks.userId, userId), eq(bookmarks.factId, factId)));
    
    return !!bookmark;
  }

  // Comments system
  async createComment(comment: InsertComment): Promise<Comment> {
    const [newComment] = await db
      .insert(comments)
      .values(comment)
      .returning();

    // Update user contribution stats
    if (comment.userId) {
      await this.incrementUserStats(comment.userId, { totalContributions: 1 });
    }

    return newComment;
  }

  async getCommentsByFactId(factId: number): Promise<CommentWithUser[]> {
    return await db
      .select({
        id: comments.id,
        factId: comments.factId,
        userId: comments.userId,
        content: comments.content,
        isApproved: comments.isApproved,
        parentId: comments.parentId,
        createdAt: comments.createdAt,
        user: {
          id: users.id,
          email: users.email,
          firstName: users.firstName,
          lastName: users.lastName,
        },
      })
      .from(comments)
      .leftJoin(users, eq(comments.userId, users.id))
      .where(and(eq(comments.factId, factId), eq(comments.isApproved, true)))
      .orderBy(asc(comments.createdAt));
  }

  // Fact flagging
  async createFactFlag(flag: InsertFactFlag): Promise<FactFlag> {
    const [newFlag] = await db
      .insert(factFlags)
      .values(flag)
      .returning();
    return newFlag;
  }

  async getFactFlags(factId?: number): Promise<FactFlag[]> {
    let query = db.select().from(factFlags);
    
    if (factId) {
      query = query.where(eq(factFlags.factId, factId));
    }
    
    return await query.orderBy(desc(factFlags.createdAt));
  }

  // Newsletter
  async subscribeNewsletter(newsletter: InsertNewsletter): Promise<Newsletter> {
    const [subscription] = await db
      .insert(newsletters)
      .values(newsletter)
      .returning();
    return subscription;
  }

  async getNewsletterByEmail(email: string): Promise<Newsletter | undefined> {
    const [subscription] = await db
      .select()
      .from(newsletters)
      .where(eq(newsletters.email, email));
    return subscription;
  }

  // Quiz system
  async createQuizQuestion(question: InsertQuizQuestion): Promise<QuizQuestion> {
    const [newQuestion] = await db
      .insert(quizQuestions)
      .values(question)
      .returning();
    return newQuestion;
  }

  async getQuizQuestionsByFactId(factId: number): Promise<QuizQuestion[]> {
    return await db
      .select()
      .from(quizQuestions)
      .where(eq(quizQuestions.factId, factId));
  }

  async createQuizAttempt(attempt: InsertQuizAttempt): Promise<QuizAttempt> {
    const [newAttempt] = await db
      .insert(quizAttempts)
      .values(attempt)
      .returning();
    return newAttempt;
  }

  async getUserQuizStats(userId: string): Promise<{ correct: number; total: number }> {
    const [stats] = await db
      .select({
        correct: sql<number>`SUM(CASE WHEN ${quizAttempts.isCorrect} THEN 1 ELSE 0 END)`,
        total: count(quizAttempts.id),
      })
      .from(quizAttempts)
      .where(eq(quizAttempts.userId, userId));
    
    return {
      correct: stats?.correct || 0,
      total: stats?.total || 0,
    };
  }

  // Reading progress
  async updateReadingProgress(progress: InsertReadingProgress): Promise<ReadingProgress> {
    const [updatedProgress] = await db
      .insert(readingProgress)
      .values(progress)
      .onConflictDoUpdate({
        target: [readingProgress.userId, readingProgress.factId],
        set: progress,
      })
      .returning();
    return updatedProgress;
  }

  async getUserReadingProgress(userId: string): Promise<ReadingProgress[]> {
    return await db
      .select()
      .from(readingProgress)
      .where(eq(readingProgress.userId, userId));
  }

  // Achievements system
  async getUserAchievements(userId: string): Promise<Achievement[]> {
    return await db
      .select({
        id: achievements.id,
        name: achievements.name,
        description: achievements.description,
        icon: achievements.icon,
        category: achievements.category,
        pointsRequired: achievements.pointsRequired,
        createdAt: achievements.createdAt,
      })
      .from(userAchievements)
      .innerJoin(achievements, eq(userAchievements.achievementId, achievements.id))
      .where(eq(userAchievements.userId, userId));
  }

  async checkAndUnlockAchievements(userId: string): Promise<Achievement[]> {
    const profile = await this.getUserProfile(userId);
    if (!profile) return [];

    // Get available achievements that user hasn't unlocked
    const unlockedAchievements = await db
      .select({ achievementId: userAchievements.achievementId })
      .from(userAchievements)
      .where(eq(userAchievements.userId, userId));

    const unlockedIds = unlockedAchievements.map(ua => ua.achievementId);

    let availableQuery = db
      .select()
      .from(achievements)
      .where(sql`${achievements.pointsRequired} <= ${profile.reputation}`);

    if (unlockedIds.length > 0) {
      availableQuery = availableQuery.where(sql`${achievements.id} NOT IN ${unlockedIds}`);
    }

    const availableAchievements = await availableQuery;

    // Unlock new achievements
    const newlyUnlocked: Achievement[] = [];
    for (const achievement of availableAchievements) {
      await db
        .insert(userAchievements)
        .values({
          userId,
          achievementId: achievement.id,
        });
      newlyUnlocked.push(achievement);
    }

    return newlyUnlocked;
  }

  // Leaderboard
  async getLeaderboard(limit: number = 10): Promise<Array<UserProfile & { user: User }>> {
    return await db
      .select({
        id: userProfiles.id,
        userId: userProfiles.userId,
        reputation: userProfiles.reputation,
        streak: userProfiles.streak,
        lastLoginDate: userProfiles.lastLoginDate,
        totalVotes: userProfiles.totalVotes,
        totalContributions: userProfiles.totalContributions,
        preferences: userProfiles.preferences,
        createdAt: userProfiles.createdAt,
        updatedAt: userProfiles.updatedAt,
        user: {
          id: users.id,
          email: users.email,
          firstName: users.firstName,
          lastName: users.lastName,
          profileImageUrl: users.profileImageUrl,
          createdAt: users.createdAt,
          updatedAt: users.updatedAt,
        },
      })
      .from(userProfiles)
      .innerJoin(users, eq(userProfiles.userId, users.id))
      .orderBy(desc(userProfiles.reputation))
      .limit(limit);
  }

  // Admin functions
  async getPendingFacts(): Promise<MedicalFact[]> {
    return await db
      .select()
      .from(medicalFacts)
      .where(eq(medicalFacts.isApproved, false))
      .orderBy(desc(medicalFacts.createdAt));
  }

  async approveFact(factId: number): Promise<MedicalFact> {
    const [fact] = await db
      .update(medicalFacts)
      .set({ isApproved: true })
      .where(eq(medicalFacts.id, factId))
      .returning();
    return fact;
  }

  async getPendingComments(): Promise<CommentWithUser[]> {
    return await db
      .select({
        id: comments.id,
        factId: comments.factId,
        userId: comments.userId,
        content: comments.content,
        isApproved: comments.isApproved,
        parentId: comments.parentId,
        createdAt: comments.createdAt,
        user: {
          id: users.id,
          email: users.email,
          firstName: users.firstName,
          lastName: users.lastName,
        },
      })
      .from(comments)
      .leftJoin(users, eq(comments.userId, users.id))
      .where(eq(comments.isApproved, false))
      .orderBy(desc(comments.createdAt));
  }

  async approveComment(commentId: number): Promise<Comment> {
    const [comment] = await db
      .update(comments)
      .set({ isApproved: true })
      .where(eq(comments.id, commentId))
      .returning();
    return comment;
  }

  // Helper methods
  private async incrementUserStats(userId: string, increments: Partial<Pick<UserProfile, 'totalVotes' | 'totalContributions' | 'reputation'>>): Promise<void> {
    const profile = await this.getUserProfile(userId);
    
    if (!profile) {
      // Create profile if it doesn't exist
      await this.createUserProfile({
        userId,
        reputation: increments.reputation || 0,
        totalVotes: increments.totalVotes || 0,
        totalContributions: increments.totalContributions || 0,
      });
    } else {
      // Update existing profile
      await this.updateUserProfile(userId, {
        reputation: (profile.reputation || 0) + (increments.reputation || 0),
        totalVotes: (profile.totalVotes || 0) + (increments.totalVotes || 0),
        totalContributions: (profile.totalContributions || 0) + (increments.totalContributions || 0),
      });
    }
  }
}