import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertVoteSchema, insertNewsletterSchema } from "@shared/schema";
import { z } from "zod";
import bcrypt from "bcrypt";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get all medical facts with vote counts
  app.get("/api/facts", async (req, res) => {
    try {
      const facts = await storage.getFactsWithVotes();
      res.json(facts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch facts" });
    }
  });

  // Create a new user account
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(409).json({ error: "User already exists" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(userData.password, 10);
      
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword
      });

      // Don't return password
      const { password, ...userResponse } = user;
      res.status(201).json(userResponse);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create user" });
    }
  });

  // Submit a vote
  app.post("/api/votes", async (req, res) => {
    try {
      const voteData = insertVoteSchema.parse(req.body);
      
      // Validate fact exists
      const fact = await storage.getFactById(voteData.factId);
      if (!fact) {
        return res.status(404).json({ error: "Fact not found" });
      }

      // Check if user already voted (if userId provided)
      if (voteData.userId) {
        const existingVote = await storage.getUserVoteForFact(voteData.userId, voteData.factId);
        if (existingVote) {
          return res.status(409).json({ error: "User already voted on this fact" });
        }
      }

      const vote = await storage.createVote(voteData);
      res.status(201).json(vote);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to submit vote" });
    }
  });

  // Subscribe to newsletter
  app.post("/api/newsletter", async (req, res) => {
    try {
      const newsletterData = insertNewsletterSchema.parse(req.body);
      
      // Check if email already subscribed
      const existing = await storage.getNewsletterByEmail(newsletterData.email);
      if (existing && existing.isActive) {
        return res.status(409).json({ error: "Email already subscribed" });
      }

      const subscription = await storage.subscribeNewsletter(newsletterData);
      res.status(201).json(subscription);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to subscribe to newsletter" });
    }
  });

  // Add new medical fact (for authenticated users)
  app.post("/api/facts", async (req, res) => {
    try {
      const factData = {
        titleEn: req.body.title,
        titleFr: req.body.title, // In a real app, this would be properly translated
        titleEs: req.body.title,
        detailsEn: req.body.details,
        detailsFr: req.body.details,
        detailsEs: req.body.details,
        category: req.body.category,
        isApproved: false // New facts need approval
      };

      const fact = await storage.createFact(factData);
      res.status(201).json(fact);
    } catch (error) {
      res.status(500).json({ error: "Failed to create fact" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
