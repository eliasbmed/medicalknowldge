import { pgTable, text, serial, integer, timestamp, varchar, boolean, primaryKey, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { relations } from "drizzle-orm";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const medicalFacts = pgTable("medical_facts", {
  id: serial("id").primaryKey(),
  titleEn: text("title_en").notNull(),
  titleFr: text("title_fr").notNull(),
  titleEs: text("title_es").notNull(),
  detailsEn: text("details_en").notNull(),
  detailsFr: text("details_fr").notNull(),
  detailsEs: text("details_es").notNull(),
  category: varchar("category", { length: 50 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  isApproved: boolean("is_approved").default(false).notNull(),
});

export const votes = pgTable("votes", {
  id: serial("id").primaryKey(),
  factId: integer("fact_id").references(() => medicalFacts.id).notNull(),
  userId: varchar("user_id").references(() => users.id),
  guestRole: varchar("guest_role", { length: 50 }),
  guestSpecialty: varchar("guest_specialty", { length: 100 }),
  voteType: varchar("vote_type", { length: 20 }).notNull(), // 'agree' or 'disagree'
  language: varchar("language", { length: 5 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const newsletters = pgTable("newsletters", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  language: varchar("language", { length: 5 }).notNull(),
  subscribedAt: timestamp("subscribed_at").defaultNow().notNull(),
  isActive: boolean("is_active").default(true).notNull(),
});

// Sessions table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Extended user profile for gamification
export const userProfiles = pgTable("user_profiles", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull().unique(),
  reputation: integer("reputation").default(0).notNull(),
  streak: integer("streak").default(0).notNull(),
  lastLoginDate: timestamp("last_login_date"),
  totalVotes: integer("total_votes").default(0).notNull(),
  totalContributions: integer("total_contributions").default(0).notNull(),
  preferences: jsonb("preferences"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Bookmarks for saving important facts
export const bookmarks = pgTable("bookmarks", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  factId: integer("fact_id").references(() => medicalFacts.id).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Comments on facts - declare first without self-reference
export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  factId: integer("fact_id").references(() => medicalFacts.id).notNull(),
  userId: varchar("user_id").references(() => users.id),
  content: text("content").notNull(),
  isApproved: boolean("is_approved").default(false).notNull(),
  parentId: integer("parent_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Fact flags for reporting issues
export const factFlags = pgTable("fact_flags", {
  id: serial("id").primaryKey(),
  factId: integer("fact_id").references(() => medicalFacts.id).notNull(),
  userId: varchar("user_id").references(() => users.id),
  reason: varchar("reason", { length: 100 }).notNull(),
  description: text("description"),
  status: varchar("status", { length: 20 }).default("pending").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Achievements system
export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  description: text("description").notNull(),
  icon: varchar("icon", { length: 50 }).notNull(),
  category: varchar("category", { length: 50 }).notNull(),
  pointsRequired: integer("points_required").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// User achievements tracking
export const userAchievements = pgTable("user_achievements", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  achievementId: integer("achievement_id").references(() => achievements.id).notNull(),
  unlockedAt: timestamp("unlocked_at").defaultNow().notNull(),
});

// Quiz questions
export const quizQuestions = pgTable("quiz_questions", {
  id: serial("id").primaryKey(),
  factId: integer("fact_id").references(() => medicalFacts.id).notNull(),
  questionEn: text("question_en").notNull(),
  questionFr: text("question_fr").notNull(),
  questionEs: text("question_es").notNull(),
  options: jsonb("options").notNull(), // Array of options with translations
  correctAnswer: integer("correct_answer").notNull(),
  difficulty: integer("difficulty").default(1).notNull(), // 1-5 scale
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Quiz attempts
export const quizAttempts = pgTable("quiz_attempts", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id),
  questionId: integer("question_id").references(() => quizQuestions.id).notNull(),
  selectedAnswer: integer("selected_answer").notNull(),
  isCorrect: boolean("is_correct").notNull(),
  timeSpent: integer("time_spent"), // in seconds
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Fact reading progress
export const readingProgress = pgTable("reading_progress", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  factId: integer("fact_id").references(() => medicalFacts.id).notNull(),
  isCompleted: boolean("is_completed").default(false).notNull(),
  timeSpent: integer("time_spent"), // in seconds
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertMedicalFactSchema = createInsertSchema(medicalFacts).omit({
  id: true,
  createdAt: true,
  isApproved: true,
});

export const insertVoteSchema = createInsertSchema(votes).omit({
  id: true,
  createdAt: true,
});

export const insertNewsletterSchema = createInsertSchema(newsletters).omit({
  id: true,
  subscribedAt: true,
  isActive: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type MedicalFact = typeof medicalFacts.$inferSelect;
export type InsertMedicalFact = z.infer<typeof insertMedicalFactSchema>;
export type Vote = typeof votes.$inferSelect;
export type InsertVote = z.infer<typeof insertVoteSchema>;
export type Newsletter = typeof newsletters.$inferSelect;
export type InsertNewsletter = z.infer<typeof insertNewsletterSchema>;

// Relations
export const usersRelations = relations(users, ({ one, many }) => ({
  profile: one(userProfiles, {
    fields: [users.id],
    references: [userProfiles.userId],
  }),
  votes: many(votes),
  bookmarks: many(bookmarks),
  comments: many(comments),
  achievements: many(userAchievements),
}));

export const medicalFactsRelations = relations(medicalFacts, ({ many }) => ({
  votes: many(votes),
  comments: many(comments),
  bookmarks: many(bookmarks),
  flags: many(factFlags),
  quizQuestions: many(quizQuestions),
}));

// Insert schemas
export const insertUserProfileSchema = createInsertSchema(userProfiles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertBookmarkSchema = createInsertSchema(bookmarks).omit({
  id: true,
  createdAt: true,
});

export const insertCommentSchema = createInsertSchema(comments).omit({
  id: true,
  createdAt: true,
  isApproved: true,
});

export const insertFactFlagSchema = createInsertSchema(factFlags).omit({
  id: true,
  createdAt: true,
  status: true,
});

export const insertQuizQuestionSchema = createInsertSchema(quizQuestions).omit({
  id: true,
  createdAt: true,
});

export const insertQuizAttemptSchema = createInsertSchema(quizAttempts).omit({
  id: true,
  createdAt: true,
});

export const insertReadingProgressSchema = createInsertSchema(readingProgress).omit({
  id: true,
  createdAt: true,
});

// Types
export type UserProfile = typeof userProfiles.$inferSelect;
export type InsertUserProfile = z.infer<typeof insertUserProfileSchema>;
export type Bookmark = typeof bookmarks.$inferSelect;
export type InsertBookmark = z.infer<typeof insertBookmarkSchema>;
export type Comment = typeof comments.$inferSelect;
export type InsertComment = z.infer<typeof insertCommentSchema>;
export type FactFlag = typeof factFlags.$inferSelect;
export type InsertFactFlag = z.infer<typeof insertFactFlagSchema>;
export type Achievement = typeof achievements.$inferSelect;
export type UserAchievement = typeof userAchievements.$inferSelect;
export type QuizQuestion = typeof quizQuestions.$inferSelect;
export type InsertQuizQuestion = z.infer<typeof insertQuizQuestionSchema>;
export type QuizAttempt = typeof quizAttempts.$inferSelect;
export type InsertQuizAttempt = z.infer<typeof insertQuizAttemptSchema>;
export type ReadingProgress = typeof readingProgress.$inferSelect;
export type InsertReadingProgress = z.infer<typeof insertReadingProgressSchema>;
export type UpsertUser = typeof users.$inferInsert;

// Utility types for frontend
export interface FactWithVotes extends MedicalFact {
  agreeVotes: number;
  disagreeVotes: number;
  isBookmarked?: boolean;
  commentsCount?: number;
  readingProgress?: ReadingProgress;
}

export interface LocalizedFact {
  id: number;
  title: string;
  details: string;
  category: string;
  agreeVotes: number;
  disagreeVotes: number;
  isBookmarked?: boolean;
  commentsCount?: number;
  isApproved?: boolean;
  createdAt?: Date;
}

export interface ExtendedUser extends User {
  profile?: UserProfile;
}

export interface CommentWithUser extends Comment {
  user?: {
    id: string;
    email: string;
    role: string;
  };
}

export interface QuizQuestionWithOptions extends QuizQuestion {
  localizedQuestion: string;
  localizedOptions: string[];
}
