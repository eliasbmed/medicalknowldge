import { useLanguage, type Language } from "@/hooks/use-language";
import type { FactWithVotes, LocalizedFact } from "@shared/schema";

export function useLocalizedFacts(facts: FactWithVotes[]): LocalizedFact[] {
  const { language } = useLanguage();
  
  return facts.map(fact => ({
    id: fact.id,
    title: getLocalizedTitle(fact, language),
    details: getLocalizedDetails(fact, language),
    category: fact.category,
    agreeVotes: fact.agreeVotes,
    disagreeVotes: fact.disagreeVotes
  }));
}

function getLocalizedTitle(fact: FactWithVotes, language: Language): string {
  switch (language) {
    case 'fr':
      return fact.titleFr;
    case 'es':
      return fact.titleEs;
    default:
      return fact.titleEn;
  }
}

function getLocalizedDetails(fact: FactWithVotes, language: Language): string {
  switch (language) {
    case 'fr':
      return fact.detailsFr;
    case 'es':
      return fact.detailsEs;
    default:
      return fact.detailsEn;
  }
}
