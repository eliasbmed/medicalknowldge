export const translations = {
  en: {
    header: {
      title: "Must Know Medical Facts",
      subtitle: "Essential medical knowledge for healthcare professionals and students"
    },
    home: {
      title: "Essential Medical Knowledge",
      subtitle: "Curated medical facts for healthcare professionals",
      searchPlaceholder: "Search medical facts...",
      noResults: "No facts found matching your search",
      loading: "Loading medical facts...",
      error: "Failed to load facts"
    },
    sorting: {
      relevance: "Most Relevant",
      newest: "Newest",
      popular: "Most Popular",
      controversial: "Most Controversial"
    },
    filters: {
      category: "Category",
      difficulty: "Difficulty",
      all: "All",
      beginner: "Beginner",
      intermediate: "Intermediate",
      advanced: "Advanced",
      clearAll: "Clear Filters"
    },
    categories: {
      emergency: "Emergency Medicine",
      cardiology: "Cardiology",
      surgery: "Surgery",
      internalMedicine: "Internal Medicine"
    },
    tabs: {
      all: "All Facts",
      trending: "Trending",
      recent: "Recent",
      bookmarked: "Bookmarked"
    },
    stats: {
      totalFacts: "Total Facts",
      totalVotes: "Total Votes",
      todayAdded: "Added Today",
      categories: "Categories"
    },
    pagination: {
      previous: "Previous",
      next: "Next",
      page: "Page"
    },
    bookmarks: {
      added: "Bookmarked",
      removed: "Bookmark Removed",
      addedDescription: "Fact saved to your bookmarks",
      removedDescription: "Fact removed from bookmarks",
      empty: "No bookmarked facts yet"
    },
    share: {
      copied: "Link Copied",
      copiedDescription: "Link copied to clipboard"
    },
    auth: {
      required: "Login Required",
      bookmarkRequired: "Please log in to bookmark facts"
    },
    votes: {
      distribution: "Vote Distribution",
      noVotes: "No votes yet"
    },
    comments: {
      recent: "Recent Comments",
      loadMore: "Load more comments"
    },
    status: {
      pending: "Pending Review",
      trending: "Trending"
    },
    reading: {
      progress: "Reading Progress"
    },
    difficulty: {
      intermediate: "Intermediate"
    },
    evidence: {
      levelA: "Evidence Level A"
    },
    quiz: {
      mode: "Quiz Mode",
      description: "Test your medical knowledge with interactive quizzes",
      loading: "Loading quiz questions...",
      howItWorks: "How It Works",
      step1: "Answer 10 random medical questions",
      step2: "Get instant feedback on each answer",
      step3: "See detailed explanations",
      step4: "Track your progress over time",
      questionsAvailable: "questions available",
      start: "Start Quiz",
      loginForProgress: "Login to track your progress",
      completed: "Quiz Completed!",
      excellent: "Excellent work!",
      good: "Good job!",
      needsImprovement: "Keep studying!",
      score: "Score",
      correct: "Correct",
      avgTime: "Avg Time",
      review: "Review Answers",
      tryAgain: "Try Again",
      exitQuiz: "Exit Quiz",
      next: "Next Question",
      finish: "Finish Quiz"
    },
    leaderboard: {
      title: "Leaderboard",
      subtitle: "Top contributors and medical knowledge leaders",
      yourPosition: "Your Position",
      rank: "Rank",
      points: "Points",
      streak: "Day Streak",
      topUsers: "Top Users",
      achievements: "Achievements",
      votes: "votes",
      contributions: "contributions",
      dayStreak: "day streak",
      pts: "pts",
      ptsRequired: "pts required"
    },
    achievements: {
      popular: "Popular Achievements",
      mostUnlocked: "Most unlocked by users",
      unlocked: "users unlocked",
      viewAll: "View All"
    },
    addFact: {
      contribute: "Contribute Fact"
    },
    common: {
      agree: "Agree",
      disagree: "Disagree",
      votes: "votes",
      error: "Error",
      back: "Back",
      more: "more"
    },
    searchFilters: {
      tryDifferentFilters: "Try different search terms or filters"
    },
    navigation: {
      home: "Home",
      quiz: "Quiz",
      leaderboard: "Leaderboard",
      profile: "Profile",
      logout: "Logout",
      login: "Login"
    },
    newsletter: {
      title: "Stay Updated",
      subtitle: "Get the latest medical knowledge delivered to your inbox",
      placeholder: "Enter your email",
      subscribe: "Subscribe",
      success: "Thank you for subscribing!",
      error: "Please enter a valid email address"
    },
    vote: {
      success: "Vote recorded successfully!"
    },
    factModal: {
      title: "Add Medical Fact",
      factTitle: "Fact title",
      factDetails: "Fact details",
      category: "Category",
      submit: "Submit",
      cancel: "Cancel",
      success: "Fact submitted successfully!",
      error: "Please fill in all fields"
    },
    factCategories: {
      emergency: "Emergency Medicine",
      cardiology: "Cardiology",
      surgery: "Surgery",
      internalMedicine: "Internal Medicine",
      pediatrics: "Pediatrics",
      gynecology: "Gynecology",
      neurology: "Neurology",
      psychiatry: "Psychiatry",
      dermatology: "Dermatology",
      ophthalmology: "Ophthalmology",
      orthopedics: "Orthopedics",
      radiology: "Radiology",
      anesthesiology: "Anesthesiology",
      pathology: "Pathology",
      pharmacology: "Pharmacology",
      geriatrics: "Geriatrics",
      other: "Other"
    },
    general: {
      cancel: "Cancel",
      submit: "Submit",
      loading: "Loading...",
      error: "Something went wrong",
      tryAgain: "Try Again"
    }
  },
  fr: {
    header: {
      title: "Faits Médicaux à Connaître Absolument",
      subtitle: "Connaissances médicales essentielles pour les professionnels de santé et étudiants"
    },
    home: {
      title: "Connaissances Médicales Essentielles",
      subtitle: "Faits médicaux sélectionnés pour les professionnels de santé",
      searchPlaceholder: "Rechercher des faits médicaux...",
      noResults: "Aucun fait trouvé correspondant à votre recherche",
      loading: "Chargement des faits médicaux...",
      error: "Échec du chargement des faits"
    },
    sorting: {
      relevance: "Plus Pertinent",
      newest: "Plus Récent",
      popular: "Plus Populaire",
      controversial: "Plus Controversé"
    },
    filters: {
      category: "Catégorie",
      difficulty: "Difficulté",
      all: "Tous",
      beginner: "Débutant",
      intermediate: "Intermédiaire",
      advanced: "Avancé",
      clearAll: "Effacer les Filtres"
    },
    categories: {
      emergency: "Médecine d'Urgence",
      cardiology: "Cardiologie",
      surgery: "Chirurgie",
      internalMedicine: "Médecine Interne"
    },
    tabs: {
      all: "Tous les Faits",
      trending: "Tendance",
      recent: "Récent",
      bookmarked: "Favoris"
    },
    stats: {
      totalFacts: "Total des Faits",
      totalVotes: "Total des Votes",
      todayAdded: "Ajouté Aujourd'hui",
      categories: "Catégories"
    },
    pagination: {
      previous: "Précédent",
      next: "Suivant",
      page: "Page"
    },
    bookmarks: {
      added: "Mis en Favori",
      removed: "Favori Supprimé",
      addedDescription: "Fait sauvegardé dans vos favoris",
      removedDescription: "Fait supprimé des favoris",
      empty: "Aucun fait en favori pour le moment"
    },
    share: {
      copied: "Lien Copié",
      copiedDescription: "Lien copié dans le presse-papiers"
    },
    auth: {
      required: "Connexion Requise",
      bookmarkRequired: "Veuillez vous connecter pour mettre en favori"
    },
    votes: {
      distribution: "Distribution des Votes",
      noVotes: "Aucun vote pour le moment"
    },
    comments: {
      recent: "Commentaires Récents",
      loadMore: "Charger plus de commentaires"
    },
    status: {
      pending: "En Attente de Révision",
      trending: "Tendance"
    },
    reading: {
      progress: "Progrès de Lecture"
    },
    difficulty: {
      intermediate: "Intermédiaire"
    },
    evidence: {
      levelA: "Niveau de Preuve A"
    },
    quiz: {
      mode: "Mode Quiz",
      description: "Testez vos connaissances médicales avec des quiz interactifs",
      loading: "Chargement des questions du quiz...",
      howItWorks: "Comment ça Marche",
      step1: "Répondez à 10 questions médicales aléatoires",
      step2: "Obtenez des commentaires instantanés sur chaque réponse",
      step3: "Voir des explications détaillées",
      step4: "Suivez vos progrès au fil du temps",
      questionsAvailable: "questions disponibles",
      start: "Commencer le Quiz",
      loginForProgress: "Connectez-vous pour suivre vos progrès",
      completed: "Quiz Terminé!",
      excellent: "Excellent travail!",
      good: "Bon travail!",
      needsImprovement: "Continuez à étudier!",
      score: "Score",
      correct: "Correct",
      avgTime: "Temps Moyen",
      review: "Réviser les Réponses",
      tryAgain: "Réessayer",
      exitQuiz: "Quitter le Quiz",
      next: "Question Suivante",
      finish: "Terminer le Quiz"
    },
    leaderboard: {
      title: "Classement",
      subtitle: "Top des contributeurs et leaders en connaissances médicales",
      yourPosition: "Votre Position",
      rank: "Rang",
      points: "Points",
      streak: "Série de Jours",
      topUsers: "Top Utilisateurs",
      achievements: "Réalisations",
      votes: "votes",
      contributions: "contributions",
      dayStreak: "série de jours",
      pts: "pts",
      ptsRequired: "pts requis"
    },
    achievements: {
      popular: "Réalisations Populaires",
      mostUnlocked: "Les plus débloquées par les utilisateurs",
      unlocked: "utilisateurs ont débloqué",
      viewAll: "Voir Tout"
    },
    addFact: {
      contribute: "Contribuer un Fait"
    },
    common: {
      agree: "D'accord",
      disagree: "Pas d'accord",
      votes: "votes",
      error: "Erreur",
      back: "Retour",
      more: "plus"
    },
    searchFilters: {
      tryDifferentFilters: "Essayez différents termes de recherche ou filtres"
    },
    navigation: {
      home: "Accueil",
      quiz: "Quiz",
      leaderboard: "Classement",
      profile: "Profil",
      logout: "Déconnexion",
      login: "Connexion"
    },
    newsletter: {
      title: "Restez Informé",
      subtitle: "Recevez les dernières connaissances médicales dans votre boîte mail",
      placeholder: "Entrez votre email",
      subscribe: "S'abonner",
      success: "Merci de vous être abonné!",
      error: "Veuillez entrer une adresse email valide"
    },
    vote: {
      success: "Vote enregistré avec succès!"
    },
    factModal: {
      title: "Ajouter un Fait Médical",
      factTitle: "Titre du fait",
      factDetails: "Détails du fait",
      category: "Catégorie",
      submit: "Soumettre",
      cancel: "Annuler",
      success: "Fait soumis avec succès!",
      error: "Veuillez remplir tous les champs"
    },
    factCategories: {
      emergency: "Médecine d'Urgence",
      cardiology: "Cardiologie",
      surgery: "Chirurgie",
      internalMedicine: "Médecine Interne",
      pediatrics: "Pédiatrie",
      gynecology: "Gynécologie",
      neurology: "Neurologie",
      psychiatry: "Psychiatrie",
      dermatology: "Dermatologie",
      ophthalmology: "Ophtalmologie",
      orthopedics: "Orthopédie",
      radiology: "Radiologie",
      anesthesiology: "Anesthésiologie",
      pathology: "Pathologie",
      pharmacology: "Pharmacologie",
      geriatrics: "Gériatrie",
      other: "Autre"
    },
    general: {
      cancel: "Annuler",
      submit: "Soumettre",
      loading: "Chargement...",
      error: "Quelque chose s'est mal passé",
      tryAgain: "Réessayer"
    }
  },
  es: {
    header: {
      title: "Datos Médicos Que Debes Conocer",
      subtitle: "Conocimiento médico esencial para profesionales de la salud y estudiantes"
    },
    home: {
      title: "Conocimiento Médico Esencial",
      subtitle: "Datos médicos seleccionados para profesionales de la salud",
      searchPlaceholder: "Buscar datos médicos...",
      noResults: "No se encontraron datos que coincidan con su búsqueda",
      loading: "Cargando datos médicos...",
      error: "Error al cargar los datos"
    },
    sorting: {
      relevance: "Más Relevante",
      newest: "Más Reciente",
      popular: "Más Popular",
      controversial: "Más Controvertido"
    },
    filters: {
      category: "Categoría",
      difficulty: "Dificultad",
      all: "Todos",
      beginner: "Principiante",
      intermediate: "Intermedio",
      advanced: "Avanzado",
      clearAll: "Limpiar Filtros"
    },
    categories: {
      emergency: "Medicina de Emergencia",
      cardiology: "Cardiología",
      surgery: "Cirugía",
      internalMedicine: "Medicina Interna"
    },
    tabs: {
      all: "Todos los Datos",
      trending: "Tendencia",
      recent: "Reciente",
      bookmarked: "Favoritos"
    },
    stats: {
      totalFacts: "Total de Datos",
      totalVotes: "Total de Votos",
      todayAdded: "Agregado Hoy",
      categories: "Categorías"
    },
    pagination: {
      previous: "Anterior",
      next: "Siguiente",
      page: "Página"
    },
    bookmarks: {
      added: "Marcado como Favorito",
      removed: "Favorito Eliminado",
      addedDescription: "Dato guardado en sus favoritos",
      removedDescription: "Dato eliminado de favoritos",
      empty: "No hay datos favoritos aún"
    },
    share: {
      copied: "Enlace Copiado",
      copiedDescription: "Enlace copiado al portapapeles"
    },
    auth: {
      required: "Inicio de Sesión Requerido",
      bookmarkRequired: "Por favor inicie sesión para marcar como favorito"
    },
    votes: {
      distribution: "Distribución de Votos",
      noVotes: "No hay votos aún"
    },
    comments: {
      recent: "Comentarios Recientes",
      loadMore: "Cargar más comentarios"
    },
    status: {
      pending: "Pendiente de Revisión",
      trending: "Tendencia"
    },
    reading: {
      progress: "Progreso de Lectura"
    },
    difficulty: {
      intermediate: "Intermedio"
    },
    evidence: {
      levelA: "Nivel de Evidencia A"
    },
    quiz: {
      mode: "Modo Quiz",
      description: "Prueba tu conocimiento médico con cuestionarios interactivos",
      loading: "Cargando preguntas del quiz...",
      howItWorks: "Cómo Funciona",
      step1: "Responde 10 preguntas médicas aleatorias",
      step2: "Obtén retroalimentación instantánea en cada respuesta",
      step3: "Ve explicaciones detalladas",
      step4: "Rastrea tu progreso a lo largo del tiempo",
      questionsAvailable: "preguntas disponibles",
      start: "Iniciar Quiz",
      loginForProgress: "Inicia sesión para rastrear tu progreso",
      completed: "¡Quiz Completado!",
      excellent: "¡Excelente trabajo!",
      good: "¡Buen trabajo!",
      needsImprovement: "¡Sigue estudiando!",
      score: "Puntuación",
      correct: "Correcto",
      avgTime: "Tiempo Promedio",
      review: "Revisar Respuestas",
      tryAgain: "Intentar de Nuevo",
      exitQuiz: "Salir del Quiz",
      next: "Siguiente Pregunta",
      finish: "Terminar Quiz"
    },
    leaderboard: {
      title: "Tabla de Clasificación",
      subtitle: "Top contribuyentes y líderes en conocimiento médico",
      yourPosition: "Tu Posición",
      rank: "Rango",
      points: "Puntos",
      streak: "Racha de Días",
      topUsers: "Top Usuarios",
      achievements: "Logros",
      votes: "votos",
      contributions: "contribuciones",
      dayStreak: "racha de días",
      pts: "pts",
      ptsRequired: "pts requeridos"
    },
    achievements: {
      popular: "Logros Populares",
      mostUnlocked: "Más desbloqueados por usuarios",
      unlocked: "usuarios desbloquearon",
      viewAll: "Ver Todos"
    },
    addFact: {
      contribute: "Contribuir Dato"
    },
    common: {
      agree: "De acuerdo",
      disagree: "En desacuerdo",
      votes: "votos",
      error: "Error",
      back: "Atrás",
      more: "más"
    },
    searchFilters: {
      tryDifferentFilters: "Prueba diferentes términos de búsqueda o filtros"
    },
    navigation: {
      home: "Inicio",
      quiz: "Quiz",
      leaderboard: "Clasificación",
      profile: "Perfil",
      logout: "Cerrar Sesión",
      login: "Iniciar Sesión"
    },
    newsletter: {
      title: "Mantente Actualizado",
      subtitle: "Recibe el último conocimiento médico en tu bandeja de entrada",
      placeholder: "Ingresa tu email",
      subscribe: "Suscribirse",
      success: "¡Gracias por suscribirte!",
      error: "Por favor ingresa una dirección de email válida"
    },
    vote: {
      success: "¡Voto registrado exitosamente!"
    },
    factModal: {
      title: "Agregar Dato Médico",
      factTitle: "Título del dato",
      factDetails: "Detalles del dato",
      category: "Categoría",
      submit: "Enviar",
      cancel: "Cancelar",
      success: "¡Dato enviado exitosamente!",
      error: "Por favor completa todos los campos"
    },
    factCategories: {
      emergency: "Medicina de Emergencia",
      cardiology: "Cardiología",
      surgery: "Cirugía",
      internalMedicine: "Medicina Interna",
      pediatrics: "Pediatría",
      gynecology: "Ginecología",
      neurology: "Neurología",
      psychiatry: "Psiquiatría",
      dermatology: "Dermatología",
      ophthalmology: "Oftalmología",
      orthopedics: "Ortopedia",
      radiology: "Radiología",
      anesthesiology: "Anestesiología",
      pathology: "Patología",
      pharmacology: "Farmacología",
      geriatrics: "Geriatría",
      other: "Otro"
    },
    general: {
      cancel: "Cancelar",
      submit: "Enviar",
      loading: "Cargando...",
      error: "Algo salió mal",
      tryAgain: "Intentar de Nuevo"
    }
  }
};