import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useLanguage } from "@/hooks/use-language";
import MainNav from "@/components/navigation/main-nav";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Trophy, 
  Medal, 
  Award, 
  TrendingUp, 
  Clock, 
  Star,
  Crown,
  Users,
  Target
} from "lucide-react";

interface LeaderboardUser {
  id: string;
  firstName: string | null;
  lastName: string | null;
  email: string;
  profileImageUrl: string | null;
  reputation: number;
  totalVotes: number;
  totalContributions: number;
  streak: number;
  rank: number;
}

interface Achievement {
  id: number;
  name: string;
  description: string;
  icon: string;
  category: string;
  pointsRequired: number;
  unlockedBy: number;
}

export default function Leaderboard() {
  const { t } = useLanguage();
  const { user, isAuthenticated } = useAuth();

  const { data: topUsers = [], isLoading: usersLoading } = useQuery<LeaderboardUser[]>({
    queryKey: ["/api/leaderboard"],
  });

  const { data: achievements = [], isLoading: achievementsLoading } = useQuery<Achievement[]>({
    queryKey: ["/api/achievements"],
  });

  const { data: userProfile } = useQuery({
    queryKey: ["/api/profile"],
    enabled: isAuthenticated,
  });

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="h-6 w-6 text-yellow-500" />;
      case 2:
        return <Medal className="h-6 w-6 text-gray-400" />;
      case 3:
        return <Award className="h-6 w-6 text-amber-600" />;
      default:
        return <span className="text-lg font-bold text-gray-600">#{rank}</span>;
    }
  };

  const getRankBadgeColor = (rank: number) => {
    switch (rank) {
      case 1:
        return "bg-gradient-to-r from-yellow-400 to-yellow-600";
      case 2:
        return "bg-gradient-to-r from-gray-300 to-gray-500";
      case 3:
        return "bg-gradient-to-r from-amber-400 to-amber-600";
      default:
        return "bg-gradient-to-r from-blue-400 to-blue-600";
    }
  };

  const topAchievements = achievements
    .sort((a, b) => b.unlockedBy - a.unlockedBy)
    .slice(0, 6);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
      <MainNav />
      <div className="lg:ml-64 pt-20 lg:pt-0 p-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              <Trophy className="h-16 w-16 text-yellow-500" />
            </div>
            <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              {t('leaderboard.title')}
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              {t('leaderboard.subtitle')}
            </p>
          </div>

          {/* User's Current Position */}
          {isAuthenticated && userProfile && (
            <Card className="mb-8 border-2 border-blue-200 bg-gradient-to-r from-blue-50 to-purple-50">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={user?.profileImageUrl || undefined} />
                      <AvatarFallback>
                        {user?.firstName?.[0] || user?.email?.[0] || 'U'}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-semibold text-lg">
                        {t('leaderboard.yourPosition')}
                      </h3>
                      <p className="text-gray-600">
                        {user?.firstName || user?.email}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-6">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-600">
                        #{userProfile.rank || '---'}
                      </div>
                      <div className="text-sm text-gray-600">{t('leaderboard.rank')}</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-purple-600">
                        {userProfile.reputation || 0}
                      </div>
                      <div className="text-sm text-gray-600">{t('leaderboard.points')}</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">
                        {userProfile.streak || 0}
                      </div>
                      <div className="text-sm text-gray-600">{t('leaderboard.streak')}</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <Tabs defaultValue="users" className="space-y-6">
            <TabsList className="grid w-full grid-cols-2 lg:w-96 mx-auto">
              <TabsTrigger value="users" className="flex items-center space-x-2">
                <Users className="h-4 w-4" />
                <span>{t('leaderboard.topUsers')}</span>
              </TabsTrigger>
              <TabsTrigger value="achievements" className="flex items-center space-x-2">
                <Star className="h-4 w-4" />
                <span>{t('leaderboard.achievements')}</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="users">
              {usersLoading ? (
                <div className="space-y-4">
                  {[...Array(10)].map((_, i) => (
                    <Card key={i} className="animate-pulse">
                      <CardContent className="pt-6">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-gray-200 rounded-full"></div>
                          <div className="flex-1">
                            <div className="h-4 bg-gray-200 rounded w-1/3 mb-2"></div>
                            <div className="h-3 bg-gray-200 rounded w-1/4"></div>
                          </div>
                          <div className="w-16 h-8 bg-gray-200 rounded"></div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="space-y-4">
                  {topUsers.map((user, index) => (
                    <Card key={user.id} className={`transition-all hover:shadow-lg ${
                      index < 3 ? 'border-2' : ''
                    } ${
                      index === 0 ? 'border-yellow-300 bg-gradient-to-r from-yellow-50 to-yellow-100' :
                      index === 1 ? 'border-gray-300 bg-gradient-to-r from-gray-50 to-gray-100' :
                      index === 2 ? 'border-amber-300 bg-gradient-to-r from-amber-50 to-amber-100' :
                      ''
                    }`}>
                      <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-4">
                            <div className="flex items-center justify-center w-12 h-12 rounded-full">
                              {getRankIcon(user.rank)}
                            </div>
                            <Avatar className="h-12 w-12">
                              <AvatarImage src={user.profileImageUrl || undefined} />
                              <AvatarFallback>
                                {user.firstName?.[0] || user.email[0]}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <h3 className="font-semibold text-lg">
                                {user.firstName ? `${user.firstName} ${user.lastName || ''}`.trim() : user.email}
                              </h3>
                              <div className="flex items-center space-x-4 text-sm text-gray-600">
                                <div className="flex items-center space-x-1">
                                  <TrendingUp className="h-3 w-3" />
                                  <span>{user.totalVotes} {t('leaderboard.votes')}</span>
                                </div>
                                <div className="flex items-center space-x-1">
                                  <Target className="h-3 w-3" />
                                  <span>{user.totalContributions} {t('leaderboard.contributions')}</span>
                                </div>
                                <div className="flex items-center space-x-1">
                                  <Clock className="h-3 w-3" />
                                  <span>{user.streak} {t('leaderboard.dayStreak')}</span>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className={`inline-flex items-center px-3 py-1 rounded-full text-white font-medium ${
                              getRankBadgeColor(user.rank)
                            }`}>
                              {user.reputation} {t('leaderboard.pts')}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="achievements">
              {achievementsLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[...Array(6)].map((_, i) => (
                    <Card key={i} className="animate-pulse">
                      <CardContent className="pt-6">
                        <div className="w-12 h-12 bg-gray-200 rounded-full mb-4"></div>
                        <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded w-full mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="text-center">
                    <h2 className="text-2xl font-semibold mb-2">{t('achievements.popular')}</h2>
                    <p className="text-gray-600">{t('achievements.mostUnlocked')}</p>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {topAchievements.map((achievement) => (
                      <Card key={achievement.id} className="hover:shadow-lg transition-shadow">
                        <CardHeader className="pb-3">
                          <div className="flex items-center space-x-3">
                            <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white text-2xl">
                              {achievement.icon}
                            </div>
                            <div>
                              <CardTitle className="text-lg">{achievement.name}</CardTitle>
                              <Badge variant="outline" className="text-xs">
                                {t(`categories.${achievement.category}`)}
                              </Badge>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <p className="text-gray-600 mb-4">{achievement.description}</p>
                          <div className="flex items-center justify-between">
                            <div className="text-sm text-gray-500">
                              {achievement.pointsRequired} {t('leaderboard.ptsRequired')}
                            </div>
                            <div className="flex items-center space-x-2">
                              <Users className="h-4 w-4 text-gray-400" />
                              <span className="text-sm text-gray-600">
                                {achievement.unlockedBy} {t('achievements.unlocked')}
                              </span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>

                  {achievements.length > 6 && (
                    <div className="text-center">
                      <button className="text-blue-600 hover:text-blue-800 font-medium">
                        {t('achievements.viewAll')} ({achievements.length - 6} {t('common.more')})
                      </button>
                    </div>
                  )}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}