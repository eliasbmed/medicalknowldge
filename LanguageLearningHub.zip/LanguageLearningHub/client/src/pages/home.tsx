import { useQuery } from "@tanstack/react-query";
import { useLanguage } from "@/hooks/use-language";
import { useLocalizedFacts } from "@/lib/medical-facts";
import LanguageSwitcher from "@/components/language-switcher";
import NewsletterSection from "@/components/newsletter-section";
import FactCard from "@/components/fact-card";
import VoteModal from "@/components/modals/vote-modal";
import SignupModal from "@/components/modals/signup-modal";
import GuestVoteModal from "@/components/modals/guest-vote-modal";
import AddFactModal from "@/components/modals/add-fact-modal";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { useState } from "react";
import type { FactWithVotes } from "@shared/schema";

export default function Home() {
  const { t } = useLanguage();
  const [voteModalOpen, setVoteModalOpen] = useState(false);
  const [signupModalOpen, setSignupModalOpen] = useState(false);
  const [guestVoteModalOpen, setGuestVoteModalOpen] = useState(false);
  const [addFactModalOpen, setAddFactModalOpen] = useState(false);
  const [selectedFactId, setSelectedFactId] = useState<number | null>(null);
  const [selectedVoteType, setSelectedVoteType] = useState<'agree' | 'disagree' | null>(null);

  const { data: facts = [], isLoading, error } = useQuery<FactWithVotes[]>({
    queryKey: ["/api/facts"],
  });

  const localizedFacts = useLocalizedFacts(facts);

  const handleVote = (factId: number, voteType: 'agree' | 'disagree') => {
    setSelectedFactId(factId);
    setSelectedVoteType(voteType);
    setVoteModalOpen(true);
  };

  const handleSignupFromVote = () => {
    setVoteModalOpen(false);
    setSignupModalOpen(true);
  };

  const handleGuestVoteFromVote = () => {
    setVoteModalOpen(false);
    setGuestVoteModalOpen(true);
  };

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-white text-center">
          <h1 className="text-2xl font-bold mb-4">{t('common.error')}</h1>
          <p>Failed to load medical facts</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <LanguageSwitcher />
      
      <div className="max-w-4xl mx-auto p-5">
        {/* Header */}
        <div className="text-center mb-10 text-white">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 drop-shadow-lg">
            {t('header.title')}
          </h1>
          <p className="text-xl opacity-90">
            {t('header.subtitle')}
          </p>
        </div>

        {/* Newsletter Section */}
        <NewsletterSection />

        {/* Facts Container */}
        <div className="space-y-6 mb-20">
          {isLoading ? (
            <div className="text-center text-white">
              <p className="text-xl">{t('common.loading')}</p>
            </div>
          ) : (
            localizedFacts.map((fact) => (
              <FactCard
                key={fact.id}
                fact={fact}
                onVote={handleVote}
              />
            ))
          )}
        </div>

        {/* Add Fact Button */}
        <Button
          onClick={() => setAddFactModalOpen(true)}
          className="fixed bottom-8 right-8 w-16 h-16 rounded-full bg-red-500 hover:bg-red-600 text-white shadow-2xl hover:scale-110 transition-all duration-300 z-40"
          size="icon"
        >
          <Plus className="h-8 w-8" />
        </Button>
      </div>

      {/* Modals */}
      <VoteModal
        open={voteModalOpen}
        onOpenChange={setVoteModalOpen}
        onSignup={handleSignupFromVote}
        onGuestVote={handleGuestVoteFromVote}
      />

      <SignupModal
        open={signupModalOpen}
        onOpenChange={setSignupModalOpen}
        factId={selectedFactId}
        voteType={selectedVoteType}
      />

      <GuestVoteModal
        open={guestVoteModalOpen}
        onOpenChange={setGuestVoteModalOpen}
        factId={selectedFactId}
        voteType={selectedVoteType}
      />

      <AddFactModal
        open={addFactModalOpen}
        onOpenChange={setAddFactModalOpen}
      />
    </div>
  );
}
