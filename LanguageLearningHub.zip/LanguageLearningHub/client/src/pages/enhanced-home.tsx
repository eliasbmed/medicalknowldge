import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLanguage } from "@/hooks/use-language";
import { useAuth } from "@/hooks/useAuth";
import { useLocalizedFacts } from "@/lib/medical-facts";
import MainNav from "@/components/navigation/main-nav";
import NewsletterSection from "@/components/newsletter-section";
import EnhancedFactCard from "@/components/enhanced-fact-card";
import VoteModal from "@/components/modals/vote-modal";
import SignupModal from "@/components/modals/signup-modal";
import GuestVoteModal from "@/components/modals/guest-vote-modal";
import AddFactModal from "@/components/modals/add-fact-modal";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Filter, TrendingUp, Clock, Star } from "lucide-react";
import type { FactWithVotes } from "@shared/schema";

export default function EnhancedHome() {
  const { t } = useLanguage();
  const { isAuthenticated } = useAuth();
  const [voteModalOpen, setVoteModalOpen] = useState(false);
  const [signupModalOpen, setSignupModalOpen] = useState(false);
  const [guestVoteModalOpen, setGuestVoteModalOpen] = useState(false);
  const [addFactModalOpen, setAddFactModalOpen] = useState(false);
  const [selectedFactId, setSelectedFactId] = useState<number | null>(null);
  const [selectedVoteType, setSelectedVoteType] = useState<'agree' | 'disagree' | null>(null);
  
  // Search and filter state
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [sortBy, setSortBy] = useState<'newest' | 'popular' | 'controversial'>('newest');
  const [currentPage, setCurrentPage] = useState(0);
  const [activeTab, setActiveTab] = useState("all");

  const { data: facts = [], isLoading, error } = useQuery<FactWithVotes[]>({
    queryKey: ["/api/facts", { search: searchQuery, category: selectedCategory, sortBy, page: currentPage }],
  });

  const localizedFacts = useLocalizedFacts(facts);

  // Filter facts based on tab
  const filteredFacts = localizedFacts.filter(fact => {
    switch (activeTab) {
      case 'trending':
        return (fact.agreeVotes + fact.disagreeVotes) > 10 && 
               (fact.agreeVotes / (fact.agreeVotes + fact.disagreeVotes)) > 0.8;
      case 'recent':
        return fact.createdAt && 
               new Date(fact.createdAt).getTime() > Date.now() - 7 * 24 * 60 * 60 * 1000;
      case 'bookmarked':
        return isAuthenticated && fact.isBookmarked;
      default:
        return true;
    }
  });

  const handleVote = (factId: number, voteType: 'agree' | 'disagree') => {
    setSelectedFactId(factId);
    setSelectedVoteType(voteType);
    setVoteModalOpen(true);
  };

  const handleSignupFromVote = () => {
    setVoteModalOpen(false);
    setSignupModalOpen(true);
  };

  const handleGuestVoteFromVote = () => {
    setVoteModalOpen(false);
    setGuestVoteModalOpen(true);
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    setCurrentPage(0);
  };

  if (error) {
    return (
      <div className="min-h-screen">
        <MainNav onSearch={handleSearch} searchQuery={searchQuery} />
        <div className="lg:ml-64 pt-20 lg:pt-0 flex items-center justify-center min-h-screen">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4 text-gray-800">{t('common.error')}</h1>
            <p className="text-gray-600">Failed to load medical facts</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
      <MainNav onSearch={handleSearch} searchQuery={searchQuery} />
      <div className="lg:ml-64 pt-20 lg:pt-0">
        <div className="max-w-7xl mx-auto p-6">
          {/* Header Section */}
          <div className="text-center mb-8">
            <h1 className="text-4xl md:text-5xl mb-4 from-blue-600 to-purple-600 bg-clip-text bg-[#99abc4] text-[#355ceb] font-normal">
              {t('header.title')}
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              {t('header.subtitle')}
            </p>
          </div>

          {/* Newsletter Section */}
          <div className="mb-8">
            <NewsletterSection />
          </div>

          {/* Stats Section */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-white rounded-lg p-6 shadow-md">
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-blue-100 text-blue-600 mr-4">
                  <Star className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{facts.length}</p>
                  <p className="text-gray-600">{t('stats.totalFacts')}</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-lg p-6 shadow-md">
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-green-100 text-green-600 mr-4">
                  <TrendingUp className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">
                    {facts.reduce((sum, fact) => sum + fact.agreeVotes + fact.disagreeVotes, 0)}
                  </p>
                  <p className="text-gray-600">{t('stats.totalVotes')}</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg p-6 shadow-md">
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-purple-100 text-purple-600 mr-4">
                  <Clock className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">
                    {filteredFacts.filter(f => f.createdAt && 
                      new Date(f.createdAt).getTime() > Date.now() - 24 * 60 * 60 * 1000).length}
                  </p>
                  <p className="text-gray-600">{t('stats.todayAdded')}</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg p-6 shadow-md">
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-orange-100 text-orange-600 mr-4">
                  <Filter className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">
                    {new Set(facts.map(f => f.category)).size}
                  </p>
                  <p className="text-gray-600">{t('stats.categories')}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Filters Section */}
          <div className="bg-white rounded-lg p-6 shadow-md mb-6">
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center space-x-2">
                <Filter className="h-4 w-4 text-gray-500" />
                <span className="font-medium text-gray-700">{t('search.filters')}:</span>
              </div>
              
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder={t('filters.category')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t('filters.all')}</SelectItem>
                  <SelectItem value="emergency">{t('categories.emergency')}</SelectItem>
                  <SelectItem value="cardiology">{t('categories.cardiology')}</SelectItem>
                  <SelectItem value="surgery">{t('categories.surgery')}</SelectItem>
                  <SelectItem value="internalMedicine">{t('categories.internalMedicine')}</SelectItem>
                </SelectContent>
              </Select>

              <Select value={sortBy} onValueChange={(value: 'newest' | 'popular' | 'controversial') => setSortBy(value)}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder={t('search.sortBy')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">{t('search.newest')}</SelectItem>
                  <SelectItem value="popular">{t('search.popular')}</SelectItem>
                  <SelectItem value="controversial">{t('search.controversial')}</SelectItem>
                </SelectContent>
              </Select>

              {(selectedCategory !== "all" || sortBy !== "newest") && (
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => {
                    setSelectedCategory("all");
                    setSortBy("newest");
                    setSearchQuery("");
                  }}
                >
                  {t('filters.clearAll')}
                </Button>
              )}
            </div>
          </div>

          {/* Tabs Section */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
            <TabsList className="grid w-full grid-cols-4 lg:w-96">
              <TabsTrigger value="all" className="relative">
                {t('tabs.all')}
                <Badge variant="secondary" className="ml-2 text-xs">
                  {localizedFacts.length}
                </Badge>
              </TabsTrigger>
              <TabsTrigger value="trending">
                {t('tabs.trending')}
                <Badge variant="secondary" className="ml-2 text-xs">
                  {localizedFacts.filter(f => 
                    (f.agreeVotes + f.disagreeVotes) > 10 && 
                    (f.agreeVotes / (f.agreeVotes + f.disagreeVotes)) > 0.8
                  ).length}
                </Badge>
              </TabsTrigger>
              <TabsTrigger value="recent">
                {t('tabs.recent')}
              </TabsTrigger>
              {isAuthenticated && (
                <TabsTrigger value="bookmarked">
                  {t('tabs.bookmarked')}
                </TabsTrigger>
              )}
            </TabsList>

            <TabsContent value={activeTab} className="mt-6">
              <div className="space-y-6">
                {isLoading ? (
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {[...Array(6)].map((_, i) => (
                      <div key={i} className="bg-white rounded-2xl p-6 shadow-md animate-pulse">
                        <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
                        <div className="h-3 bg-gray-200 rounded w-1/2 mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                      </div>
                    ))}
                  </div>
                ) : filteredFacts.length === 0 ? (
                  <div className="text-center py-12">
                    <div className="text-gray-400 mb-4">
                      <Star className="h-16 w-16 mx-auto" />
                    </div>
                    <h3 className="text-lg font-medium text-gray-900 mb-2">
                      {t('search.noResults')}
                    </h3>
                    <p className="text-gray-500 mb-6">
                      {activeTab === 'bookmarked' 
                        ? t('bookmarks.empty')
                        : t('search.tryDifferentFilters')
                      }
                    </p>
                    {activeTab !== 'bookmarked' && (
                      <Button onClick={() => setAddFactModalOpen(true)}>
                        <Plus className="h-4 w-4 mr-2" />
                        {t('addFact.contribute')}
                      </Button>
                    )}
                  </div>
                ) : (
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {filteredFacts.map((fact) => (
                      <EnhancedFactCard
                        key={fact.id}
                        fact={fact}
                        onVote={handleVote}
                        onComment={(factId) => console.log('Comment on fact:', factId)}
                        onFlag={(factId) => console.log('Flag fact:', factId)}
                      />
                    ))}
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>

          {/* Pagination */}
          {filteredFacts.length > 0 && (
            <div className="flex justify-center mt-8">
              <div className="flex space-x-2">
                <Button 
                  variant="outline" 
                  disabled={currentPage === 0}
                  onClick={() => setCurrentPage(p => Math.max(0, p - 1))}
                >
                  {t('pagination.previous')}
                </Button>
                <span className="flex items-center px-4 text-sm text-gray-600">
                  {t('pagination.page')} {currentPage + 1}
                </span>
                <Button 
                  variant="outline"
                  onClick={() => setCurrentPage(p => p + 1)}
                >
                  {t('pagination.next')}
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Floating Add Button */}
        <Button
          onClick={() => setAddFactModalOpen(true)}
          className="fixed bottom-8 right-8 w-16 h-16 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white shadow-2xl hover:scale-110 transition-all duration-300 z-40"
          size="icon"
        >
          <Plus className="h-8 w-8" />
        </Button>
      </div>
      {/* Modals */}
      <VoteModal
        open={voteModalOpen}
        onOpenChange={setVoteModalOpen}
        onSignup={handleSignupFromVote}
        onGuestVote={handleGuestVoteFromVote}
      />
      <SignupModal
        open={signupModalOpen}
        onOpenChange={setSignupModalOpen}
        factId={selectedFactId}
        voteType={selectedVoteType}
      />
      <GuestVoteModal
        open={guestVoteModalOpen}
        onOpenChange={setGuestVoteModalOpen}
        factId={selectedFactId}
        voteType={selectedVoteType}
      />
      <AddFactModal
        open={addFactModalOpen}
        onOpenChange={setAddFactModalOpen}
      />
    </div>
  );
}