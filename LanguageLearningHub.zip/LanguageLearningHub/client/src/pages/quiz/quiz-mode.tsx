import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useLanguage } from "@/hooks/use-language";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import MainNav from "@/components/navigation/main-nav";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  Brain, 
  Clock, 
  CheckCircle, 
  XCircle, 
  Trophy, 
  Target,
  RotateCcw,
  Play
} from "lucide-react";

interface QuizQuestion {
  id: number;
  factId: number;
  question: string;
  options: string[];
  correctAnswer: number;
  difficulty: number;
  category: string;
}

interface QuizSession {
  questions: QuizQuestion[];
  currentIndex: number;
  answers: number[];
  startTime: Date;
  timeSpent: number[];
  isCompleted: boolean;
}

export default function QuizMode() {
  const { t } = useLanguage();
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  
  const [quizSession, setQuizSession] = useState<QuizSession | null>(null);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResults, setShowResults] = useState(false);
  const [questionStartTime, setQuestionStartTime] = useState<Date>(new Date());

  // Fetch quiz questions
  const { data: questions = [], isLoading } = useQuery<QuizQuestion[]>({
    queryKey: ["/api/quiz/questions"],
    enabled: !quizSession,
  });

  // Submit quiz attempt
  const submitAttemptMutation = useMutation({
    mutationFn: async (attempt: {
      questionId: number;
      selectedAnswer: number;
      isCorrect: boolean;
      timeSpent: number;
    }) => {
      const response = await apiRequest("POST", "/api/quiz/attempts", attempt);
      return response.json();
    },
  });

  const startQuiz = () => {
    if (questions.length === 0) return;
    
    const shuffledQuestions = [...questions]
      .sort(() => Math.random() - 0.5)
      .slice(0, 10); // Take 10 random questions

    setQuizSession({
      questions: shuffledQuestions,
      currentIndex: 0,
      answers: [],
      startTime: new Date(),
      timeSpent: [],
      isCompleted: false,
    });
    setQuestionStartTime(new Date());
  };

  const handleAnswerSelect = (answerIndex: number) => {
    setSelectedAnswer(answerIndex);
  };

  const handleNextQuestion = () => {
    if (!quizSession || selectedAnswer === null) return;

    const currentQuestion = quizSession.questions[quizSession.currentIndex];
    const timeSpent = Date.now() - questionStartTime.getTime();
    const isCorrect = selectedAnswer === currentQuestion.correctAnswer;

    // Submit attempt if user is authenticated
    if (isAuthenticated) {
      submitAttemptMutation.mutate({
        questionId: currentQuestion.id,
        selectedAnswer,
        isCorrect,
        timeSpent: Math.floor(timeSpent / 1000),
      });
    }

    const newAnswers = [...quizSession.answers, selectedAnswer];
    const newTimeSpent = [...quizSession.timeSpent, timeSpent];

    if (quizSession.currentIndex + 1 >= quizSession.questions.length) {
      // Quiz completed
      setQuizSession(prev => prev ? {
        ...prev,
        answers: newAnswers,
        timeSpent: newTimeSpent,
        isCompleted: true,
      } : null);
      setShowResults(true);
    } else {
      // Next question
      setQuizSession(prev => prev ? {
        ...prev,
        currentIndex: prev.currentIndex + 1,
        answers: newAnswers,
        timeSpent: newTimeSpent,
      } : null);
      setSelectedAnswer(null);
      setQuestionStartTime(new Date());
    }
  };

  const calculateScore = () => {
    if (!quizSession) return { correct: 0, total: 0, percentage: 0 };
    
    const correct = quizSession.answers.reduce((count, answer, index) => {
      return answer === quizSession.questions[index].correctAnswer ? count + 1 : count;
    }, 0);
    
    const total = quizSession.answers.length;
    const percentage = total > 0 ? Math.round((correct / total) * 100) : 0;
    
    return { correct, total, percentage };
  };

  const restartQuiz = () => {
    setQuizSession(null);
    setSelectedAnswer(null);
    setShowResults(false);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
        <MainNav />
        <div className="lg:ml-64 pt-20 lg:pt-0 flex items-center justify-center min-h-screen">
          <div className="text-center">
            <Brain className="h-16 w-16 mx-auto text-blue-500 animate-pulse mb-4" />
            <p className="text-gray-600">{t('quiz.loading')}</p>
          </div>
        </div>
      </div>
    );
  }

  if (showResults && quizSession) {
    const score = calculateScore();
    const totalTime = quizSession.timeSpent.reduce((sum, time) => sum + time, 0);
    const avgTimePerQuestion = totalTime / quizSession.questions.length / 1000;

    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
        <MainNav />
        <div className="lg:ml-64 pt-20 lg:pt-0 p-6">
          <div className="max-w-4xl mx-auto">
            <Card className="mb-6">
              <CardHeader className="text-center">
                <div className="mx-auto mb-4">
                  {score.percentage >= 80 ? (
                    <Trophy className="h-16 w-16 text-yellow-500" />
                  ) : score.percentage >= 60 ? (
                    <Target className="h-16 w-16 text-blue-500" />
                  ) : (
                    <Brain className="h-16 w-16 text-gray-500" />
                  )}
                </div>
                <CardTitle className="text-3xl">
                  {t('quiz.completed')}
                </CardTitle>
                <p className="text-gray-600 mt-2">
                  {score.percentage >= 80 
                    ? t('quiz.excellent')
                    : score.percentage >= 60 
                    ? t('quiz.good')
                    : t('quiz.needsImprovement')
                  }
                </p>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <div className="text-3xl font-bold text-green-600">
                      {score.percentage}%
                    </div>
                    <div className="text-sm text-gray-600">{t('quiz.score')}</div>
                  </div>
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <div className="text-3xl font-bold text-blue-600">
                      {score.correct}/{score.total}
                    </div>
                    <div className="text-sm text-gray-600">{t('quiz.correct')}</div>
                  </div>
                  <div className="text-center p-4 bg-purple-50 rounded-lg">
                    <div className="text-3xl font-bold text-purple-600">
                      {avgTimePerQuestion.toFixed(1)}s
                    </div>
                    <div className="text-sm text-gray-600">{t('quiz.avgTime')}</div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">{t('quiz.review')}</h3>
                  {quizSession.questions.map((question, index) => {
                    const userAnswer = quizSession.answers[index];
                    const isCorrect = userAnswer === question.correctAnswer;
                    
                    return (
                      <div key={question.id} className={`p-4 rounded-lg border ${
                        isCorrect ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'
                      }`}>
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center space-x-2">
                            {isCorrect ? (
                              <CheckCircle className="h-5 w-5 text-green-600" />
                            ) : (
                              <XCircle className="h-5 w-5 text-red-600" />
                            )}
                            <Badge variant="outline">
                              {t(`categories.${question.category}`)}
                            </Badge>
                          </div>
                          <div className="text-sm text-gray-500">
                            {(quizSession.timeSpent[index] / 1000).toFixed(1)}s
                          </div>
                        </div>
                        <p className="font-medium mb-2">{question.question}</p>
                        <div className="space-y-1">
                          {question.options.map((option, optionIndex) => (
                            <div key={optionIndex} className={`text-sm p-2 rounded ${
                              optionIndex === question.correctAnswer 
                                ? 'bg-green-100 text-green-800 font-medium'
                                : optionIndex === userAnswer && !isCorrect
                                ? 'bg-red-100 text-red-800'
                                : 'text-gray-600'
                            }`}>
                              {optionIndex === question.correctAnswer && '✓ '}
                              {optionIndex === userAnswer && optionIndex !== question.correctAnswer && '✗ '}
                              {option}
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="flex justify-center space-x-4 mt-6">
                  <Button onClick={restartQuiz} variant="outline">
                    <RotateCcw className="h-4 w-4 mr-2" />
                    {t('quiz.tryAgain')}
                  </Button>
                  <Button onClick={() => window.history.back()}>
                    {t('common.back')}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  if (!quizSession) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
        <MainNav />
        <div className="lg:ml-64 pt-20 lg:pt-0 p-6">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-8">
              <Brain className="h-16 w-16 mx-auto text-blue-500 mb-4" />
              <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                {t('quiz.mode')}
              </h1>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                {t('quiz.description')}
              </p>
            </div>

            <Card className="mb-6">
              <CardHeader>
                <CardTitle>{t('quiz.howItWorks')}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <span className="text-blue-600 font-semibold">1</span>
                      </div>
                      <span>{t('quiz.step1')}</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <span className="text-blue-600 font-semibold">2</span>
                      </div>
                      <span>{t('quiz.step2')}</span>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <span className="text-blue-600 font-semibold">3</span>
                      </div>
                      <span>{t('quiz.step3')}</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <span className="text-blue-600 font-semibold">4</span>
                      </div>
                      <span>{t('quiz.step4')}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="mb-6">
                    <div className="text-3xl font-bold text-gray-900 mb-2">
                      {questions.length}
                    </div>
                    <div className="text-gray-600">{t('quiz.questionsAvailable')}</div>
                  </div>
                  
                  <Button 
                    onClick={startQuiz} 
                    size="lg"
                    className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
                    disabled={questions.length === 0}
                  >
                    <Play className="h-5 w-5 mr-2" />
                    {t('quiz.start')}
                  </Button>
                  
                  {!isAuthenticated && (
                    <p className="text-sm text-gray-500 mt-4">
                      {t('quiz.loginForProgress')}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  const currentQuestion = quizSession.questions[quizSession.currentIndex];
  const progress = ((quizSession.currentIndex + 1) / quizSession.questions.length) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
      <MainNav />
      <div className="lg:ml-64 pt-20 lg:pt-0 p-6">
        <div className="max-w-4xl mx-auto">
          {/* Progress Header */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-4">
                <Badge variant="outline">
                  {t(`categories.${currentQuestion.category}`)}
                </Badge>
                <div className="flex items-center space-x-2 text-sm text-gray-600">
                  <Clock className="h-4 w-4" />
                  <span>{Math.floor((Date.now() - questionStartTime.getTime()) / 1000)}s</span>
                </div>
              </div>
              <div className="text-sm text-gray-600">
                {quizSession.currentIndex + 1} / {quizSession.questions.length}
              </div>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          {/* Question Card */}
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">
                {currentQuestion.question}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 mb-6">
                {currentQuestion.options.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => handleAnswerSelect(index)}
                    className={`w-full p-4 text-left rounded-lg border transition-all ${
                      selectedAnswer === index
                        ? 'border-blue-500 bg-blue-50 text-blue-900'
                        : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                        selectedAnswer === index
                          ? 'border-blue-500 bg-blue-500'
                          : 'border-gray-300'
                      }`}>
                        {selectedAnswer === index && (
                          <CheckCircle className="h-4 w-4 text-white" />
                        )}
                      </div>
                      <span>{option}</span>
                    </div>
                  </button>
                ))}
              </div>

              <div className="flex justify-between">
                <Button 
                  variant="outline" 
                  onClick={() => window.history.back()}
                >
                  {t('quiz.exitQuiz')}
                </Button>
                <Button 
                  onClick={handleNextQuestion}
                  disabled={selectedAnswer === null}
                  className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
                >
                  {quizSession.currentIndex + 1 === quizSession.questions.length 
                    ? t('quiz.finish') 
                    : t('quiz.next')
                  }
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}