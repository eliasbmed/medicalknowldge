import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/useAuth';
import { useLanguage } from '@/hooks/use-language';
import MainNav from '@/components/navigation/main-nav';
import { ImprovedSearch } from '@/components/improved-search';
import { FactAnalytics } from '@/components/fact-analytics';
import EnhancedFactCard from '@/components/enhanced-fact-card';
import {
  BarChart3,
  TrendingUp,
  Users,
  BookOpen,
  Clock,
  Star,
  Target,
  Award,
  Zap,
  Calendar,
  Activity
} from 'lucide-react';

export default function Dashboard() {
  const { t } = useLanguage();
  const { user, isAuthenticated } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [timeRange, setTimeRange] = useState('7d');

  const { data: dashboardStats } = useQuery({
    queryKey: ['/api/dashboard/stats'],
    enabled: isAuthenticated,
  });

  const { data: recentActivity } = useQuery({
    queryKey: ['/api/dashboard/activity'],
    enabled: isAuthenticated,
  });

  const { data: personalizedFacts } = useQuery({
    queryKey: ['/api/facts/personalized'],
    enabled: isAuthenticated,
  });

  // Mock data for development
  const mockStats = {
    totalFactsRead: 156,
    quizzesTaken: 23,
    currentStreak: 7,
    reputation: 1250,
    weeklyProgress: 85,
    categoriesExplored: 8,
    accuracyRate: 92,
    timeSpent: '2h 45m'
  };

  const mockActivity = [
    {
      type: 'quiz_completed',
      title: 'Emergency Medicine Quiz',
      score: 8,
      timestamp: '2 hours ago',
      category: 'emergency'
    },
    {
      type: 'fact_bookmarked',
      title: 'Cardiac Arrest Protocol',
      timestamp: '5 hours ago',
      category: 'cardiology'
    },
    {
      type: 'achievement_unlocked',
      title: 'Knowledge Seeker',
      description: 'Read 150+ medical facts',
      timestamp: '1 day ago'
    },
    {
      type: 'vote_cast',
      title: 'Pneumonia Treatment Guidelines',
      timestamp: '2 days ago',
      category: 'internal'
    }
  ];

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50">
        <MainNav />
        <div className="lg:ml-64 pt-20 lg:pt-0">
          <div className="max-w-4xl mx-auto p-6">
            <div className="text-center py-12">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">
                Login Required
              </h2>
              <p className="text-gray-600 mb-6">
                Please log in to access your personalized dashboard.
              </p>
              <Button onClick={() => window.location.href = '/api/login'}>
                Login to Continue
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <MainNav />
      <div className="lg:ml-64 pt-20 lg:pt-0">
        <div className="max-w-7xl mx-auto p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                Welcome back, Doctor!
              </h1>
              <p className="text-gray-600 mt-2">
                Track your medical knowledge progress and discover new insights.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="text-sm">
                <Zap className="h-4 w-4 mr-1 text-orange-500" />
                {mockStats.currentStreak} day streak
              </Badge>
              <Badge variant="secondary" className="text-sm">
                <Star className="h-4 w-4 mr-1 text-purple-500" />
                {mockStats.reputation} pts
              </Badge>
            </div>
          </div>

          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Facts Read</p>
                    <p className="text-2xl font-bold text-gray-900">{mockStats.totalFactsRead}</p>
                  </div>
                  <BookOpen className="h-8 w-8 text-blue-500" />
                </div>
                <div className="mt-4">
                  <Progress value={mockStats.weeklyProgress} className="h-2" />
                  <p className="text-xs text-gray-500 mt-2">+12 this week</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Quiz Score</p>
                    <p className="text-2xl font-bold text-gray-900">{mockStats.accuracyRate}%</p>
                  </div>
                  <Target className="h-8 w-8 text-green-500" />
                </div>
                <div className="mt-4">
                  <Progress value={mockStats.accuracyRate} className="h-2" />
                  <p className="text-xs text-gray-500 mt-2">{mockStats.quizzesTaken} quizzes taken</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Study Time</p>
                    <p className="text-2xl font-bold text-gray-900">{mockStats.timeSpent}</p>
                  </div>
                  <Clock className="h-8 w-8 text-purple-500" />
                </div>
                <div className="mt-4">
                  <p className="text-xs text-gray-500">This week</p>
                  <p className="text-xs text-green-600 font-medium">+25min from last week</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Categories</p>
                    <p className="text-2xl font-bold text-gray-900">{mockStats.categoriesExplored}</p>
                  </div>
                  <BarChart3 className="h-8 w-8 text-orange-500" />
                </div>
                <div className="mt-4">
                  <p className="text-xs text-gray-500">Areas explored</p>
                  <p className="text-xs text-blue-600 font-medium">2 new this week</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Dashboard Tabs */}
          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="activity">Activity</TabsTrigger>
              <TabsTrigger value="recommendations">For You</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              {/* Quick Actions */}
              <Card>
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                  <CardDescription>
                    Continue your medical education journey
                  </CardDescription>
                </CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Button className="h-20 flex flex-col gap-2" variant="outline">
                    <Target className="h-6 w-6" />
                    <span>Take Quiz</span>
                  </Button>
                  <Button className="h-20 flex flex-col gap-2" variant="outline">
                    <BookOpen className="h-6 w-6" />
                    <span>Browse Facts</span>
                  </Button>
                  <Button className="h-20 flex flex-col gap-2" variant="outline">
                    <Award className="h-6 w-6" />
                    <span>View Achievements</span>
                  </Button>
                </CardContent>
              </Card>

              {/* Recent Activity */}
              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {mockActivity.map((activity, index) => (
                    <div key={index} className="flex items-center gap-4 p-4 border rounded-lg">
                      <div className="p-2 bg-blue-100 rounded-full">
                        <Activity className="h-4 w-4 text-blue-600" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">{activity.title}</p>
                        <p className="text-sm text-gray-500">{activity.timestamp}</p>
                      </div>
                      {activity.category && (
                        <Badge variant="secondary" className="text-xs">
                          {activity.category}
                        </Badge>
                      )}
                      {activity.score && (
                        <Badge variant="default" className="text-xs">
                          {activity.score}/10
                        </Badge>
                      )}
                    </div>
                  ))}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="activity" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Learning Activity</CardTitle>
                  <CardDescription>
                    Your medical education progress over time
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center border-2 border-dashed border-gray-300 rounded-lg">
                    <div className="text-center">
                      <BarChart3 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-500">Activity chart would appear here</p>
                      <p className="text-sm text-gray-400 mt-2">Track your daily learning progress</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="recommendations" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Recommended for You</CardTitle>
                  <CardDescription>
                    Personalized medical facts based on your interests
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ImprovedSearch
                    searchQuery={searchQuery}
                    onSearchChange={setSearchQuery}
                    placeholder="Search personalized recommendations..."
                  />
                </CardContent>
              </Card>

              {/* Personalized Facts */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Mock personalized facts would be rendered here */}
                <Card>
                  <CardContent className="p-6">
                    <p className="text-center text-gray-500">
                      Personalized medical facts will appear here based on your learning history and preferences.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="analytics" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Knowledge Areas</CardTitle>
                    <CardDescription>
                      Your expertise across different medical categories
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      { category: 'Emergency Medicine', progress: 85, facts: 23 },
                      { category: 'Cardiology', progress: 72, facts: 18 },
                      { category: 'Internal Medicine', progress: 91, facts: 31 },
                      { category: 'Surgery', progress: 58, facts: 12 }
                    ].map((item, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="font-medium">{item.category}</span>
                          <span className="text-gray-500">{item.facts} facts</span>
                        </div>
                        <Progress value={item.progress} className="h-2" />
                        <p className="text-xs text-gray-500">{item.progress}% mastery</p>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Learning Insights</CardTitle>
                    <CardDescription>
                      Your learning patterns and achievements
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <p className="font-medium">Best Learning Day</p>
                        <p className="text-sm text-gray-500">Tuesday</p>
                      </div>
                      <Calendar className="h-5 w-5 text-blue-500" />
                    </div>
                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <p className="font-medium">Favorite Category</p>
                        <p className="text-sm text-gray-500">Internal Medicine</p>
                      </div>
                      <BookOpen className="h-5 w-5 text-green-500" />
                    </div>
                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <p className="font-medium">Current Rank</p>
                        <p className="text-sm text-gray-500">#247 globally</p>
                      </div>
                      <TrendingUp className="h-5 w-5 text-purple-500" />
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}