import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Search, 
  TrendingUp, 
  Clock, 
  Hash,
  Sparkles
} from 'lucide-react';
import { useLanguage } from '@/hooks/use-language';

interface SearchSuggestionsProps {
  onSuggestionClick: (suggestion: string) => void;
  className?: string;
}

export function SearchSuggestions({ onSuggestionClick, className }: SearchSuggestionsProps) {
  const { t } = useLanguage();
  const [suggestions] = useState({
    trending: [
      'cardiac arrest',
      'anaphylaxis',
      'stroke symptoms',
      'pneumonia',
      'sepsis'
    ],
    recent: [
      'hypertension',
      'diabetes',
      'medication errors',
      'wound care',
      'infection control'
    ],
    categories: [
      'emergency',
      'cardiology',
      'surgery',
      'internal medicine'
    ],
    popular: [
      'CPR guidelines',
      'drug interactions',
      'vital signs',
      'differential diagnosis'
    ]
  });

  const handleSuggestionClick = (suggestion: string) => {
    onSuggestionClick(suggestion);
  };

  return (
    <Card className={className}>
      <CardContent className="p-4">
        <div className="space-y-4">
          {/* Trending Searches */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <TrendingUp className="h-4 w-4 text-green-600" />
              <span className="text-sm font-medium text-gray-700">Trending Now</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {suggestions.trending.map((suggestion, index) => (
                <Badge
                  key={index}
                  variant="outline"
                  className="cursor-pointer hover:bg-green-50 hover:border-green-300 text-xs"
                  onClick={() => handleSuggestionClick(suggestion)}
                >
                  <TrendingUp className="h-3 w-3 mr-1 text-green-600" />
                  {suggestion}
                </Badge>
              ))}
            </div>
          </div>

          {/* Popular Searches */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="h-4 w-4 text-purple-600" />
              <span className="text-sm font-medium text-gray-700">Most Popular</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {suggestions.popular.map((suggestion, index) => (
                <Badge
                  key={index}
                  variant="outline"
                  className="cursor-pointer hover:bg-purple-50 hover:border-purple-300 text-xs"
                  onClick={() => handleSuggestionClick(suggestion)}
                >
                  <Sparkles className="h-3 w-3 mr-1 text-purple-600" />
                  {suggestion}
                </Badge>
              ))}
            </div>
          </div>

          {/* Categories */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Hash className="h-4 w-4 text-blue-600" />
              <span className="text-sm font-medium text-gray-700">Browse by Category</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {suggestions.categories.map((category, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  className="text-xs hover:bg-blue-50 hover:border-blue-300"
                  onClick={() => handleSuggestionClick(`category:${category}`)}
                >
                  <Hash className="h-3 w-3 mr-1 text-blue-600" />
                  {t(`categories.${category}`) || category}
                </Button>
              ))}
            </div>
          </div>

          {/* Recent Searches */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Clock className="h-4 w-4 text-gray-500" />
              <span className="text-sm font-medium text-gray-700">Recently Searched</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {suggestions.recent.map((suggestion, index) => (
                <Badge
                  key={index}
                  variant="secondary"
                  className="cursor-pointer hover:bg-gray-200 text-xs"
                  onClick={() => handleSuggestionClick(suggestion)}
                >
                  <Clock className="h-3 w-3 mr-1 text-gray-500" />
                  {suggestion}
                </Badge>
              ))}
            </div>
          </div>

          {/* Search Tips */}
          <div className="pt-3 border-t">
            <div className="flex items-start gap-2">
              <Search className="h-4 w-4 text-gray-400 mt-0.5 flex-shrink-0" />
              <div className="text-xs text-gray-500">
                <div className="font-medium mb-1">Search Tips:</div>
                <ul className="space-y-1">
                  <li>• Use quotes for exact phrases: "cardiac arrest"</li>
                  <li>• Filter by category: category:emergency</li>
                  <li>• Search in multiple languages</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}