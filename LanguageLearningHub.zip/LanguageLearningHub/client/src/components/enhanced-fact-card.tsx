import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useLanguage } from "@/hooks/use-language";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { 
  ChevronDown, 
  ChevronUp, 
  Heart, 
  MessageCircle, 
  Share2, 
  Flag, 
  Clock,
  TrendingUp,
  Bookmark,
  BookmarkCheck,
  Stethoscope,
  Activity,
  Brain,
  Syringe
} from "lucide-react";
import type { LocalizedFact } from "@shared/schema";

interface EnhancedFactCardProps {
  fact: LocalizedFact;
  onVote: (factId: number, voteType: 'agree' | 'disagree') => void;
  onComment?: (factId: number) => void;
  onFlag?: (factId: number) => void;
  showComments?: boolean;
}

export default function EnhancedFactCard({ 
  fact, 
  onVote, 
  onComment,
  onFlag,
  showComments = false 
}: EnhancedFactCardProps) {
  const { t } = useLanguage();
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showDetails, setShowDetails] = useState(false);
  const [isBookmarked, setIsBookmarked] = useState(fact.isBookmarked || false);

  const totalVotes = fact.agreeVotes + fact.disagreeVotes;
  const agreePercentage = totalVotes > 0 ? Math.round((fact.agreeVotes / totalVotes) * 100) : 0;

  // Category icon mapping
  const getCategoryIcon = (category: string) => {
    switch (category.toLowerCase()) {
      case 'emergency':
        return <Activity className="h-4 w-4 text-red-500" />;
      case 'cardiology':
        return <Heart className="h-4 w-4 text-pink-500" />;
      case 'surgery':
        return <Syringe className="h-4 w-4 text-blue-500" />;
      case 'neurology':
        return <Brain className="h-4 w-4 text-purple-500" />;
      default:
        return <Stethoscope className="h-4 w-4 text-gray-500" />;
    }
  };

  // Bookmark mutation
  const bookmarkMutation = useMutation({
    mutationFn: async (action: 'add' | 'remove') => {
      const response = await apiRequest(
        action === 'add' ? 'POST' : 'DELETE',
        `/api/bookmarks/${fact.id}`
      );
      return response.json();
    },
    onSuccess: () => {
      setIsBookmarked(!isBookmarked);
      toast({
        title: isBookmarked ? t('bookmarks.removed') : t('bookmarks.added'),
        description: isBookmarked ? 
          t('bookmarks.removedDescription') : 
          t('bookmarks.addedDescription'),
      });
      queryClient.invalidateQueries({ queryKey: ["/api/facts"] });
    },
    onError: (error: any) => {
      toast({
        title: t('common.error'),
        description: error.message || "Failed to update bookmark",
        variant: "destructive",
      });
    },
  });

  // Share functionality
  const handleShare = async () => {
    const shareData = {
      title: fact.title,
      text: fact.details,
      url: `${window.location.origin}/fact/${fact.id}`
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (error) {
        // User cancelled sharing
      }
    } else {
      // Fallback: copy to clipboard
      await navigator.clipboard.writeText(shareData.url);
      toast({
        title: t('share.copied'),
        description: t('share.copiedDescription'),
      });
    }
  };

  const handleBookmark = () => {
    if (!isAuthenticated) {
      toast({
        title: t('auth.required'),
        description: t('auth.bookmarkRequired'),
        variant: "destructive",
      });
      return;
    }
    bookmarkMutation.mutate(isBookmarked ? 'remove' : 'add');
  };

  return (
    <div className="fact-card rounded-2xl p-6 shadow-lg border border-gray-100 bg-white">
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-3">
          {getCategoryIcon(fact.category)}
          <Badge variant="secondary" className="text-xs">
            {t(`categories.${fact.category}`)}
          </Badge>
          {fact.isApproved === false && (
            <Badge variant="outline" className="text-xs text-orange-600 border-orange-300">
              {t('status.pending')}
            </Badge>
          )}
        </div>
        
        <div className="flex items-center space-x-2">
          {fact.createdAt && (
            <div className="flex items-center text-xs text-gray-500">
              <Clock className="h-3 w-3 mr-1" />
              {new Date(fact.createdAt).toLocaleDateString()}
            </div>
          )}
          
          {/* Trending indicator */}
          {agreePercentage > 80 && totalVotes > 10 && (
            <div className="flex items-center text-xs text-green-600">
              <TrendingUp className="h-3 w-3 mr-1" />
              {t('status.trending')}
            </div>
          )}
        </div>
      </div>

      {/* Fact Title */}
      <div
        className="cursor-pointer text-lg text-gray-800 mb-4 pl-5 relative hover:text-blue-600 transition-colors"
        onClick={() => setShowDetails(!showDetails)}
      >
        <span className="absolute left-0 text-blue-600 font-bold text-xl">•</span>
        <div className="flex items-center justify-between">
          <span className="flex-1 mr-2">{fact.title}</span>
          {showDetails ? <ChevronUp className="h-5 w-5 flex-shrink-0" /> : <ChevronDown className="h-5 w-5 flex-shrink-0" />}
        </div>
      </div>

      {/* Expanded Details */}
      {showDetails && (
        <div className="bg-gray-50 p-5 rounded-xl mb-5 border-l-4 border-blue-500 fade-in">
          <p className="text-gray-700 leading-relaxed mb-4">{fact.details}</p>
          
          {/* Reading Progress Indicator */}
          <div className="mb-4">
            <div className="flex items-center justify-between text-xs text-gray-600 mb-2">
              <span>{t('reading.progress')}</span>
              <span>75%</span>
            </div>
            <Progress value={75} className="h-2" />
          </div>

          {/* Tags and Metadata */}
          <div className="flex flex-wrap gap-2">
            <Badge variant="outline" className="text-xs">
              {t('difficulty.intermediate')}
            </Badge>
            <Badge variant="outline" className="text-xs">
              {t('evidence.levelA')}
            </Badge>
          </div>
        </div>
      )}

      {/* Vote Results Visualization */}
      <div className="mb-4">
        <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
          <span>{t('votes.distribution')}</span>
          <span>{totalVotes} {t('common.votes')}</span>
        </div>
        
        {totalVotes > 0 ? (
          <div className="relative">
            <Progress value={agreePercentage} className="h-3" />
            <div className="flex justify-between text-xs mt-1 text-gray-500">
              <span>{agreePercentage}% {t('common.agree')}</span>
              <span>{100 - agreePercentage}% {t('common.disagree')}</span>
            </div>
          </div>
        ) : (
          <div className="text-center text-gray-500 text-sm py-2">
            {t('votes.noVotes')}
          </div>
        )}
      </div>

      <Separator className="my-4" />

      {/* Action Buttons */}
      <div className="flex items-center justify-between">
        {/* Vote Buttons */}
        <div className="flex space-x-3">
          <Button
            onClick={() => onVote(fact.id, 'agree')}
            className="bg-green-500 hover:bg-green-600 text-white font-bold rounded-full transition-all duration-300 hover:scale-105"
            size="sm"
          >
            {t('common.agree')}
          </Button>
          <Button
            onClick={() => onVote(fact.id, 'disagree')}
            className="bg-red-500 hover:bg-red-600 text-white font-bold rounded-full transition-all duration-300 hover:scale-105"
            size="sm"
          >
            {t('common.disagree')}
          </Button>
        </div>

        {/* Secondary Actions */}
        <div className="flex items-center space-x-2">
          {/* Bookmark */}
          <Button
            variant="ghost"
            size="sm"
            onClick={handleBookmark}
            disabled={bookmarkMutation.isPending}
            className="hover:bg-gray-100"
          >
            {isBookmarked ? (
              <BookmarkCheck className="h-4 w-4 text-blue-600" />
            ) : (
              <Bookmark className="h-4 w-4" />
            )}
          </Button>

          {/* Comments */}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onComment?.(fact.id)}
            className="hover:bg-gray-100"
          >
            <MessageCircle className="h-4 w-4" />
            {fact.commentsCount && fact.commentsCount > 0 && (
              <span className="ml-1 text-xs">{fact.commentsCount}</span>
            )}
          </Button>

          {/* Share */}
          <Button
            variant="ghost"
            size="sm"
            onClick={handleShare}
            className="hover:bg-gray-100"
          >
            <Share2 className="h-4 w-4" />
          </Button>

          {/* Flag */}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onFlag?.(fact.id)}
            className="hover:bg-gray-100 text-red-500 hover:text-red-600"
          >
            <Flag className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Comments Section */}
      {showComments && (
        <div className="mt-6 pt-4 border-t border-gray-200">
          <div className="text-sm font-medium text-gray-800 mb-3">
            {t('comments.recent')}
          </div>
          {/* Comments would be loaded here */}
          <div className="text-sm text-gray-500 text-center py-4">
            {t('comments.loadMore')}
          </div>
        </div>
      )}
    </div>
  );
}