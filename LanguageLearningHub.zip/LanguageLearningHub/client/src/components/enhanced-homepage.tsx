import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAuth } from '@/hooks/useAuth';
import { useLanguage } from '@/hooks/use-language';
import MainNav from '@/components/navigation/main-nav';
import { NewsletterSection } from '@/components/newsletter-section';
import EnhancedFactCard from '@/components/enhanced-fact-card';
import { ImprovedSearch } from '@/components/improved-search';
import { SearchSuggestions } from '@/components/search-suggestions';
import { MedicalInsights } from '@/components/medical-insights';
import { FactAnalytics } from '@/components/fact-analytics';
import {
  Star,
  TrendingUp,
  Clock,
  Filter,
  Plus,
  Users,
  BookOpen,
  Target,
  Award,
  BarChart3,
  Brain
} from 'lucide-react';

interface FactWithVotes {
  id: number;
  titleEn: string;
  titleFr: string;
  titleEs: string;
  detailsEn: string;
  detailsFr: string;
  detailsEs: string;
  category: string;
  agreeVotes: number;
  disagreeVotes: number;
  createdAt: Date | null;
  isBookmarked?: boolean;
}

export default function EnhancedHomepage() {
  const { t, language } = useLanguage();
  const { user, isAuthenticated } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [sortBy, setSortBy] = useState<'newest' | 'popular' | 'controversial'>('newest');
  const [activeTab, setActiveTab] = useState('all');
  const [currentPage, setCurrentPage] = useState(0);
  const [showSearchSuggestions, setShowSearchSuggestions] = useState(false);

  const { data: facts = [], isLoading } = useQuery<FactWithVotes[]>({
    queryKey: ['/api/facts']
  });

  // Enhanced fact localization
  const localizedFacts = facts.map(fact => ({
    ...fact,
    title: language === 'fr' ? fact.titleFr : language === 'es' ? fact.titleEs : fact.titleEn,
    details: language === 'fr' ? fact.detailsFr : language === 'es' ? fact.detailsEs : fact.detailsEn,
  }));

  // Advanced filtering logic
  const filteredFacts = localizedFacts.filter(fact => {
    const matchesSearch = !searchQuery || 
      fact.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      fact.details.toLowerCase().includes(searchQuery.toLowerCase()) ||
      fact.category.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = selectedCategory === 'all' || fact.category === selectedCategory;
    
    const matchesTab = (() => {
      switch (activeTab) {
        case 'trending':
          return (fact.agreeVotes + fact.disagreeVotes) > 10 && 
                 (fact.agreeVotes / (fact.agreeVotes + fact.disagreeVotes)) > 0.8;
        case 'recent':
          return fact.createdAt && 
                 new Date(fact.createdAt).getTime() > Date.now() - 7 * 24 * 60 * 60 * 1000;
        case 'bookmarked':
          return fact.isBookmarked;
        default:
          return true;
      }
    })();

    return matchesSearch && matchesCategory && matchesTab;
  });

  // Enhanced sorting
  const sortedFacts = [...filteredFacts].sort((a, b) => {
    switch (sortBy) {
      case 'popular':
        return (b.agreeVotes + b.disagreeVotes) - (a.agreeVotes + a.disagreeVotes);
      case 'controversial':
        const aControversy = Math.abs(a.agreeVotes - a.disagreeVotes) / (a.agreeVotes + a.disagreeVotes || 1);
        const bControversy = Math.abs(b.agreeVotes - b.disagreeVotes) / (b.agreeVotes + b.disagreeVotes || 1);
        return aControversy - bControversy;
      default: // newest
        if (!a.createdAt && !b.createdAt) return 0;
        if (!a.createdAt) return 1;
        if (!b.createdAt) return -1;
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    }
  });

  const handleVote = (factId: number, voteType: 'agree' | 'disagree') => {
    console.log('Vote:', factId, voteType);
  };

  const handleSearchSuggestion = (suggestion: string) => {
    setSearchQuery(suggestion);
    setShowSearchSuggestions(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <MainNav />
      <div className="lg:ml-64 pt-20 lg:pt-0">
        <div className="max-w-7xl mx-auto p-6">
          {/* Enhanced Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2 bg-blue-100 text-blue-800 px-4 py-2 rounded-full text-sm font-medium mb-4">
              <Brain className="h-4 w-4" />
              {t('header.title')}
            </div>
            <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-blue-800 bg-clip-text text-transparent mb-4">
              {t('header.title')}
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              {t('header.subtitle')}
            </p>
          </div>

          {/* Enhanced Search Section */}
          <div className="mb-8">
            <Card className="relative overflow-visible shadow-lg border-0 bg-white/80 backdrop-blur-sm">
              <CardContent className="p-6">
                <ImprovedSearch
                  searchQuery={searchQuery}
                  onSearchChange={setSearchQuery}
                  placeholder={t('home.searchPlaceholder')}
                />
              </CardContent>
            </Card>
          </div>

          {/* Medical Insights */}
          {isAuthenticated && (
            <div className="mb-8">
              <MedicalInsights />
            </div>
          )}

          {/* Newsletter Section */}
          <div className="mb-8">
            <NewsletterSection />
          </div>

          {/* Enhanced Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-500 to-blue-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-100 text-sm font-medium">Total Facts</p>
                    <p className="text-3xl font-bold">{facts.length}</p>
                    <p className="text-blue-100 text-xs mt-1">+{Math.floor(facts.length * 0.1)} this week</p>
                  </div>
                  <BookOpen className="h-10 w-10 text-blue-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg bg-gradient-to-br from-green-500 to-green-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-100 text-sm font-medium">Community Votes</p>
                    <p className="text-3xl font-bold">
                      {facts.reduce((sum, fact) => sum + fact.agreeVotes + fact.disagreeVotes, 0)}
                    </p>
                    <p className="text-green-100 text-xs mt-1">92% accuracy rate</p>
                  </div>
                  <Users className="h-10 w-10 text-green-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg bg-gradient-to-br from-purple-500 to-purple-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-100 text-sm font-medium">Categories</p>
                    <p className="text-3xl font-bold">
                      {new Set(facts.map(f => f.category)).size}
                    </p>
                    <p className="text-purple-100 text-xs mt-1">Specialized areas</p>
                  </div>
                  <Target className="h-10 w-10 text-purple-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg bg-gradient-to-br from-orange-500 to-orange-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-orange-100 text-sm font-medium">Today's Facts</p>
                    <p className="text-3xl font-bold">
                      {filteredFacts.filter(f => f.createdAt && 
                        new Date(f.createdAt).getTime() > Date.now() - 24 * 60 * 60 * 1000).length}
                    </p>
                    <p className="text-orange-100 text-xs mt-1">Fresh content</p>
                  </div>
                  <Clock className="h-10 w-10 text-orange-200" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Advanced Filters */}
          <Card className="mb-6 border-0 shadow-lg bg-white/80 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex flex-wrap items-center gap-4">
                <div className="flex items-center space-x-2">
                  <Filter className="h-4 w-4 text-gray-500" />
                  <span className="font-medium text-gray-700">{t('search.filters')}:</span>
                </div>
                
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-48 bg-white">
                    <SelectValue placeholder={t('filters.category')} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t('filters.all')}</SelectItem>
                    <SelectItem value="emergency">{t('categories.emergency')}</SelectItem>
                    <SelectItem value="cardiology">{t('categories.cardiology')}</SelectItem>
                    <SelectItem value="surgery">{t('categories.surgery')}</SelectItem>
                    <SelectItem value="internalMedicine">{t('categories.internalMedicine')}</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={sortBy} onValueChange={(value: 'newest' | 'popular' | 'controversial') => setSortBy(value)}>
                  <SelectTrigger className="w-48 bg-white">
                    <SelectValue placeholder={t('search.sortBy')} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="newest">{t('search.newest')}</SelectItem>
                    <SelectItem value="popular">{t('search.popular')}</SelectItem>
                    <SelectItem value="controversial">{t('search.controversial')}</SelectItem>
                  </SelectContent>
                </Select>

                {(selectedCategory !== "all" || sortBy !== "newest") && (
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      setSelectedCategory("all");
                      setSortBy("newest");
                      setSearchQuery("");
                    }}
                    className="bg-white"
                  >
                    {t('filters.clearAll')}
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Enhanced Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
            <TabsList className="grid w-full grid-cols-4 lg:w-96 bg-white shadow-lg">
              <TabsTrigger value="all" className="relative data-[state=active]:bg-blue-500 data-[state=active]:text-white">
                {t('tabs.all')}
                <Badge variant="secondary" className="ml-2 text-xs bg-gray-100">
                  {localizedFacts.length}
                </Badge>
              </TabsTrigger>
              <TabsTrigger value="trending" className="data-[state=active]:bg-green-500 data-[state=active]:text-white">
                {t('tabs.trending')}
                <Badge variant="secondary" className="ml-2 text-xs bg-gray-100">
                  {localizedFacts.filter(f => 
                    (f.agreeVotes + f.disagreeVotes) > 10 && 
                    (f.agreeVotes / (f.agreeVotes + f.disagreeVotes)) > 0.8
                  ).length}
                </Badge>
              </TabsTrigger>
              <TabsTrigger value="recent" className="data-[state=active]:bg-purple-500 data-[state=active]:text-white">
                {t('tabs.recent')}
              </TabsTrigger>
              {isAuthenticated && (
                <TabsTrigger value="bookmarked" className="data-[state=active]:bg-orange-500 data-[state=active]:text-white">
                  {t('tabs.bookmarked')}
                </TabsTrigger>
              )}
            </TabsList>

            <TabsContent value={activeTab} className="mt-6">
              <div className="space-y-6">
                {isLoading ? (
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {[...Array(6)].map((_, i) => (
                      <Card key={i} className="animate-pulse border-0 shadow-lg">
                        <CardContent className="p-6">
                          <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
                          <div className="h-3 bg-gray-200 rounded w-1/2 mb-2"></div>
                          <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : sortedFacts.length === 0 ? (
                  <Card className="border-0 shadow-lg">
                    <CardContent className="text-center py-12">
                      <div className="text-gray-400 mb-4">
                        <Star className="h-16 w-16 mx-auto" />
                      </div>
                      <h3 className="text-lg font-medium text-gray-900 mb-2">
                        {t('search.noResults')}
                      </h3>
                      <p className="text-gray-500 mb-6">
                        {activeTab === 'bookmarked' 
                          ? t('bookmarks.empty')
                          : t('search.tryDifferentFilters')
                        }
                      </p>
                      {activeTab !== 'bookmarked' && (
                        <Button className="bg-gradient-to-r from-blue-500 to-purple-600 text-white">
                          <Plus className="h-4 w-4 mr-2" />
                          {t('addFact.contribute')}
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                ) : (
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {sortedFacts.map((fact) => (
                      <div key={fact.id} className="space-y-4">
                        <EnhancedFactCard
                          fact={fact}
                          onVote={handleVote}
                          onComment={(factId) => console.log('Comment on fact:', factId)}
                          onFlag={(factId) => console.log('Flag fact:', factId)}
                        />
                        <FactAnalytics fact={fact} className="lg:hidden" />
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}