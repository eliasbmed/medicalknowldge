import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useLanguage } from "@/hooks/use-language";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function NewsletterSection() {
  const { t, language } = useLanguage();
  const { toast } = useToast();
  const [email, setEmail] = useState("");

  const subscribeMutation = useMutation({
    mutationFn: async (data: { email: string; language: string }) => {
      const response = await apiRequest("POST", "/api/newsletter", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: t('newsletter.subscribed'),
        description: t('newsletter.description'),
      });
      setEmail("");
    },
    onError: (error: any) => {
      toast({
        title: t('common.error'),
        description: error.message || "Failed to subscribe",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email && email.includes("@")) {
      subscribeMutation.mutate({ email, language });
    }
  };

  return (
    <div className="glass-card rounded-2xl p-6 mb-8 text-center">
      <h3 className="text-white text-2xl font-semibold mb-4">
        📧 {t('newsletter.title')}
      </h3>
      <p className="text-white mb-6 opacity-90">
        {t('newsletter.description')}
      </p>
      <form onSubmit={handleSubmit} className="flex flex-col md:flex-row gap-3 max-w-md mx-auto">
        <Input
          type="email"
          placeholder={t('newsletter.placeholder')}
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="flex-1 bg-white text-gray-800"
          required
        />
        <Button
          type="submit"
          disabled={subscribeMutation.isPending}
          className="bg-green-500 hover:bg-green-600 text-white font-bold transition-colors duration-300"
        >
          {subscribeMutation.isPending ? t('common.loading') : t('newsletter.subscribe')}
        </Button>
      </form>
    </div>
  );
}
