import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  TrendingUp, 
  TrendingDown, 
  Users, 
  MessageCircle, 
  ThumbsUp, 
  ThumbsDown,
  Eye,
  Clock,
  BarChart3
} from 'lucide-react';
import { useLanguage } from '@/hooks/use-language';
import type { FactWithVotes } from '@shared/schema';

interface FactAnalyticsProps {
  fact: FactWithVotes;
  className?: string;
}

export function FactAnalytics({ fact, className }: FactAnalyticsProps) {
  const { t } = useLanguage();
  const [analytics, setAnalytics] = useState({
    engagementRate: 0,
    controversyScore: 0,
    trendingScore: 0,
    readingTime: 2
  });

  useEffect(() => {
    // Calculate analytics metrics
    const totalVotes = fact.agreeVotes + fact.disagreeVotes;
    const engagementRate = totalVotes > 0 ? Math.min(100, (totalVotes / 10) * 100) : 0;
    const controversyScore = totalVotes > 0 ? 
      Math.abs(fact.agreeVotes - fact.disagreeVotes) / totalVotes * 100 : 0;
    const trendingScore = totalVotes > 5 && fact.agreeVotes / totalVotes > 0.7 ? 85 : 45;
    
    // Estimate reading time based on content length
    const wordCount = (fact.titleEn + ' ' + fact.detailsEn).split(' ').length;
    const readingTime = Math.ceil(wordCount / 200); // Average reading speed

    setAnalytics({
      engagementRate,
      controversyScore: 100 - controversyScore,
      trendingScore,
      readingTime
    });
  }, [fact]);

  const getEngagementLevel = () => {
    if (analytics.engagementRate >= 80) return { label: 'High', color: 'bg-green-500' };
    if (analytics.engagementRate >= 50) return { label: 'Medium', color: 'bg-yellow-500' };
    return { label: 'Low', color: 'bg-red-500' };
  };

  const getTrendStatus = () => {
    if (analytics.trendingScore >= 80) return { 
      icon: TrendingUp, 
      label: 'Trending', 
      color: 'text-green-600' 
    };
    if (analytics.trendingScore >= 60) return { 
      icon: BarChart3, 
      label: 'Growing', 
      color: 'text-blue-600' 
    };
    return { 
      icon: TrendingDown, 
      label: 'Stable', 
      color: 'text-gray-600' 
    };
  };

  const engagement = getEngagementLevel();
  const trend = getTrendStatus();
  const TrendIcon = trend.icon;

  return (
    <Card className={className}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-medium">Analytics Overview</CardTitle>
          <Badge variant="outline" className="text-xs">
            <TrendIcon className="h-3 w-3 mr-1" />
            {trend.label}
          </Badge>
        </div>
        <CardDescription className="text-xs">
          Performance metrics and engagement stats
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Engagement Metrics */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <div className="flex items-center text-xs text-gray-600">
              <Users className="h-3 w-3 mr-1" />
              Engagement
            </div>
            <div className="flex items-center gap-2">
              <Progress 
                value={analytics.engagementRate} 
                className="flex-1 h-2" 
              />
              <span className="text-xs font-medium min-w-[3rem]">
                {Math.round(analytics.engagementRate)}%
              </span>
            </div>
            <Badge 
              variant="secondary" 
              className={`text-xs ${engagement.color} text-white`}
            >
              {engagement.label}
            </Badge>
          </div>

          <div className="space-y-2">
            <div className="flex items-center text-xs text-gray-600">
              <BarChart3 className="h-3 w-3 mr-1" />
              Agreement
            </div>
            <div className="flex items-center gap-2">
              <Progress 
                value={analytics.controversyScore} 
                className="flex-1 h-2" 
              />
              <span className="text-xs font-medium min-w-[3rem]">
                {Math.round(analytics.controversyScore)}%
              </span>
            </div>
            <div className="text-xs text-gray-500">
              {analytics.controversyScore > 70 ? 'High consensus' : 'Mixed opinions'}
            </div>
          </div>
        </div>

        {/* Vote Distribution */}
        <div className="space-y-2">
          <div className="text-xs text-gray-600 font-medium">Vote Distribution</div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 text-xs">
              <ThumbsUp className="h-3 w-3 text-green-600" />
              <span className="font-medium">{fact.agreeVotes}</span>
            </div>
            <Progress 
              value={fact.agreeVotes + fact.disagreeVotes > 0 ? 
                (fact.agreeVotes / (fact.agreeVotes + fact.disagreeVotes)) * 100 : 0
              } 
              className="flex-1 h-2"
            />
            <div className="flex items-center gap-1 text-xs">
              <span className="font-medium">{fact.disagreeVotes}</span>
              <ThumbsDown className="h-3 w-3 text-red-600" />
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-2 pt-2 border-t">
          <div className="text-center">
            <div className="flex items-center justify-center text-blue-600 mb-1">
              <Eye className="h-3 w-3" />
            </div>
            <div className="text-xs font-medium">Views</div>
            <div className="text-xs text-gray-500">
              {(fact.agreeVotes + fact.disagreeVotes) * 3 + 12}
            </div>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center text-orange-600 mb-1">
              <MessageCircle className="h-3 w-3" />
            </div>
            <div className="text-xs font-medium">Comments</div>
            <div className="text-xs text-gray-500">
              {Math.floor((fact.agreeVotes + fact.disagreeVotes) / 3)}
            </div>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center text-purple-600 mb-1">
              <Clock className="h-3 w-3" />
            </div>
            <div className="text-xs font-medium">Read Time</div>
            <div className="text-xs text-gray-500">
              {analytics.readingTime}m
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}