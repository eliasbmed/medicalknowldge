import { useState } from "react";
import { useLanguage } from "@/hooks/use-language";
import { Button } from "@/components/ui/button";
import { ChevronDown, ChevronUp } from "lucide-react";
import type { LocalizedFact } from "@shared/schema";

interface FactCardProps {
  fact: LocalizedFact;
  onVote: (factId: number, voteType: 'agree' | 'disagree') => void;
}

export default function FactCard({ fact, onVote }: FactCardProps) {
  const { t } = useLanguage();
  const [showDetails, setShowDetails] = useState(false);

  const totalVotes = fact.agreeVotes + fact.disagreeVotes;
  const agreePercentage = totalVotes > 0 ? Math.round((fact.agreeVotes / totalVotes) * 100) : 0;

  return (
    <div className="fact-card rounded-2xl p-6 shadow-lg">
      <div
        className="cursor-pointer text-lg text-gray-800 mb-5 pl-5 relative hover:text-blue-600 transition-colors"
        onClick={() => setShowDetails(!showDetails)}
      >
        <span className="absolute left-0 text-blue-600 font-bold text-xl">•</span>
        <span className="flex items-center justify-between">
          {fact.title}
          {showDetails ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
        </span>
      </div>

      {showDetails && (
        <div className="bg-gray-50 p-5 rounded-xl mb-5 border-l-4 border-blue-500 fade-in">
          <p className="text-gray-700 leading-relaxed">{fact.details}</p>
          <div className="mt-3 text-sm text-gray-600">
            <span className="inline-block bg-blue-100 text-blue-800 px-2 py-1 rounded">
              {t(`categories.${fact.category}`)}
            </span>
          </div>
        </div>
      )}

      <div className="flex justify-between items-center pt-5 border-t border-gray-200">
        <span className="font-semibold text-gray-600">{t('common.voteQuestion')}</span>
        <div className="flex space-x-4">
          <Button
            onClick={() => onVote(fact.id, 'agree')}
            className="bg-green-500 hover:bg-green-600 text-white font-bold rounded-full transition-all duration-300 hover:scale-105 min-w-[100px]"
          >
            {t('common.agree')}
          </Button>
          <Button
            onClick={() => onVote(fact.id, 'disagree')}
            className="bg-red-500 hover:bg-red-600 text-white font-bold rounded-full transition-all duration-300 hover:scale-105 min-w-[100px]"
          >
            {t('common.disagree')}
          </Button>
        </div>
      </div>

      <div className="mt-4 p-3 bg-gray-100 rounded-lg text-center">
        <span className="text-sm text-gray-600">
          {totalVotes} {t('common.votes')}: {agreePercentage}% {t('common.essential')}
        </span>
      </div>
    </div>
  );
}
