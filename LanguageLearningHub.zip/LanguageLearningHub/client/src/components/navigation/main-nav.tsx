import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useLanguage } from "@/hooks/use-language";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { 
  Search, 
  Menu, 
  Home, 
  BookOpen, 
  Vote, 
  Plus, 
  User, 
  Trophy, 
  Settings,
  Heart,
  Stethoscope,
  Brain,
  Activity
} from "lucide-react";

interface MainNavProps {
  onSearch?: (query: string) => void;
  searchQuery?: string;
}

export default function MainNav({ onSearch, searchQuery = "" }: MainNavProps) {
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);
  const [searchValue, setSearchValue] = useState(searchQuery);
  const { user, isAuthenticated } = useAuth();
  const { t } = useLanguage();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch?.(searchValue);
  };

  const navigation = [
    {
      name: t('nav.browse'),
      href: "/",
      icon: BookOpen,
      current: location === "/",
    },
    {
      name: t('nav.myVotes'),
      href: "/my-votes",
      icon: Vote,
      current: location === "/my-votes",
      requireAuth: true,
    },
    {
      name: t('nav.bookmarks'),
      href: "/bookmarks",
      icon: Heart,
      current: location === "/bookmarks",
      requireAuth: true,
    },
    {
      name: t('nav.quiz'),
      href: "/quiz",
      icon: Brain,
      current: location === "/quiz",
    },
    {
      name: t('nav.leaderboard'),
      href: "/leaderboard",
      icon: Trophy,
      current: location === "/leaderboard",
    },
    {
      name: t('nav.contribute'),
      href: "/contribute",
      icon: Plus,
      current: location === "/contribute",
    },
  ];

  const categories = [
    { name: t('categories.emergency'), icon: Activity, color: "bg-red-500" },
    { name: t('categories.cardiology'), icon: Heart, color: "bg-pink-500" },
    { name: t('categories.surgery'), icon: Stethoscope, color: "bg-blue-500" },
    { name: t('categories.internalMedicine'), icon: User, color: "bg-green-500" },
  ];

  const NavContent = () => (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="p-4 border-b border-white/20">
        <Link href="/">
          <div className="flex items-center space-x-2">
            <Stethoscope className="h-8 w-8 text-white" />
            <span className="text-white font-bold text-lg">MedFacts</span>
          </div>
        </Link>
      </div>

      {/* Search Bar */}
      <div className="p-4 border-b border-white/20">
        <form onSubmit={handleSearch} className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            type="text"
            placeholder={t('search.placeholder')}
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-gray-300"
          />
        </form>
      </div>

      {/* User Profile Section */}
      {isAuthenticated && user && (
        <div className="p-4 border-b border-white/20">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
              {user.profileImageUrl ? (
                <img 
                  src={user.profileImageUrl} 
                  alt="Profile" 
                  className="w-full h-full rounded-full object-cover"
                />
              ) : (
                <User className="h-5 w-5 text-white" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white font-medium truncate">
                {user.firstName || user.email}
              </p>
              <div className="flex items-center space-x-2 mt-1">
                <Badge variant="secondary" className="text-xs">
                  Level 5
                </Badge>
                <span className="text-xs text-white/70">1,250 pts</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Navigation Links */}
      <div className="flex-1 p-4 space-y-2">
        <div className="text-white/70 text-sm font-medium mb-3">
          {t('nav.main')}
        </div>
        
        {navigation.map((item) => {
          if (item.requireAuth && !isAuthenticated) return null;
          
          return (
            <Link key={item.name} href={item.href}>
              <div className={`flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors ${
                item.current 
                  ? 'bg-white/20 text-white' 
                  : 'text-white/70 hover:bg-white/10 hover:text-white'
              }`}>
                <item.icon className="h-5 w-5" />
                <span className="font-medium">{item.name}</span>
              </div>
            </Link>
          );
        })}

        {/* Categories */}
        <div className="mt-8">
          <div className="text-white/70 text-sm font-medium mb-3">
            {t('nav.categories')}
          </div>
          {categories.map((category) => (
            <Link key={category.name} href={`/?category=${encodeURIComponent(category.name)}`}>
              <div className="flex items-center space-x-3 px-3 py-2 rounded-lg text-white/70 hover:bg-white/10 hover:text-white transition-colors">
                <div className={`w-4 h-4 rounded-full ${category.color}`} />
                <span className="font-medium">{category.name}</span>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Bottom Actions */}
      <div className="p-4 border-t border-white/20 space-y-2">
        {isAuthenticated ? (
          <>
            <Link href="/profile">
              <Button variant="ghost" className="w-full justify-start text-white hover:bg-white/10">
                <Settings className="h-4 w-4 mr-2" />
                {t('nav.settings')}
              </Button>
            </Link>
            <Button 
              variant="ghost" 
              className="w-full justify-start text-white hover:bg-white/10"
              onClick={() => window.location.href = '/api/logout'}
            >
              <User className="h-4 w-4 mr-2" />
              {t('nav.logout')}
            </Button>
          </>
        ) : (
          <Button 
            className="w-full bg-white text-gray-900 hover:bg-gray-100"
            onClick={() => window.location.href = '/api/login'}
          >
            {t('nav.login')}
          </Button>
        )}
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Navigation */}
      <div className="hidden lg:block fixed left-0 top-0 h-full w-64 bg-gradient-to-b from-blue-600 to-purple-700 z-40">
        <NavContent />
      </div>

      {/* Mobile Navigation */}
      <div className="lg:hidden fixed top-0 left-0 right-0 bg-gradient-to-r from-blue-600 to-purple-700 p-4 z-50">
        <div className="flex items-center justify-between">
          <Link href="/">
            <div className="flex items-center space-x-2">
              <Stethoscope className="h-6 w-6 text-white" />
              <span className="text-white font-bold">MedFacts</span>
            </div>
          </Link>
          
          <div className="flex items-center space-x-2">
            {/* Mobile Search */}
            <form onSubmit={handleSearch} className="hidden sm:flex relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                type="text"
                placeholder={t('search.placeholder')}
                value={searchValue}
                onChange={(e) => setSearchValue(e.target.value)}
                className="pl-10 w-48 bg-white/10 border-white/20 text-white placeholder:text-gray-300"
              />
            </form>

            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="text-white">
                  <Menu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-64 p-0 bg-gradient-to-b from-blue-600 to-purple-700">
                <NavContent />
              </SheetContent>
            </Sheet>
          </div>
        </div>

        {/* Mobile Search Bar (visible on small screens) */}
        <div className="sm:hidden mt-3">
          <form onSubmit={handleSearch} className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              type="text"
              placeholder={t('search.placeholder')}
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
              className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-gray-300"
            />
          </form>
        </div>
      </div>
    </>
  );
}