import { useState, useEffect, useRef } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { 
  Search, 
  Filter, 
  X, 
  Clock, 
  TrendingUp,
  Hash,
  Sparkles
} from 'lucide-react';
import { useLanguage } from '@/hooks/use-language';
import { SearchSuggestions } from './search-suggestions';

interface ImprovedSearchProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onFilterChange?: (filters: SearchFilters) => void;
  placeholder?: string;
  className?: string;
}

interface SearchFilters {
  category?: string;
  difficulty?: string;
  dateRange?: string;
  hasVotes?: boolean;
}

export function ImprovedSearch({ 
  searchQuery, 
  onSearchChange, 
  onFilterChange,
  placeholder,
  className 
}: ImprovedSearchProps) {
  const { t } = useLanguage();
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [searchHistory, setSearchHistory] = useState<string[]>([]);
  const [activeFilters, setActiveFilters] = useState<SearchFilters>({});
  const [showSuggestions, setShowSuggestions] = useState(false);
  const searchRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Load search history from localStorage
    const saved = localStorage.getItem('medFacts_searchHistory');
    if (saved) {
      setSearchHistory(JSON.parse(saved));
    }
  }, []);

  const handleSearchChange = (value: string) => {
    onSearchChange(value);
    
    // Save to search history if it's a meaningful search
    if (value.length > 2 && !searchHistory.includes(value)) {
      const newHistory = [value, ...searchHistory].slice(0, 10);
      setSearchHistory(newHistory);
      localStorage.setItem('medFacts_searchHistory', JSON.stringify(newHistory));
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    // Handle special category searches
    if (suggestion.startsWith('category:')) {
      const category = suggestion.replace('category:', '');
      setActiveFilters(prev => ({ ...prev, category }));
      onFilterChange?.({ ...activeFilters, category });
    } else {
      handleSearchChange(suggestion);
      if (searchRef.current) {
        searchRef.current.value = suggestion;
      }
    }
    setShowSuggestions(false);
  };

  const removeFilter = (filterKey: keyof SearchFilters) => {
    const newFilters = { ...activeFilters };
    delete newFilters[filterKey];
    setActiveFilters(newFilters);
    onFilterChange?.(newFilters);
  };

  const clearAllFilters = () => {
    setActiveFilters({});
    onFilterChange?.({});
    handleSearchChange('');
    if (searchRef.current) {
      searchRef.current.value = '';
    }
  };

  const getFilterBadges = () => {
    const badges = [];
    if (activeFilters.category) {
      badges.push(
        <Badge key="category" variant="secondary" className="text-xs">
          <Hash className="h-3 w-3 mr-1" />
          {t(`categories.${activeFilters.category}`) || activeFilters.category}
          <X 
            className="h-3 w-3 ml-1 cursor-pointer" 
            onClick={() => removeFilter('category')}
          />
        </Badge>
      );
    }
    if (activeFilters.difficulty) {
      badges.push(
        <Badge key="difficulty" variant="secondary" className="text-xs">
          <Sparkles className="h-3 w-3 mr-1" />
          {activeFilters.difficulty}
          <X 
            className="h-3 w-3 ml-1 cursor-pointer" 
            onClick={() => removeFilter('difficulty')}
          />
        </Badge>
      );
    }
    return badges;
  };

  return (
    <div className={`space-y-3 ${className}`}>
      {/* Main Search Bar */}
      <div className="relative">
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
            <Input
              ref={searchRef}
              type="text"
              placeholder={placeholder || t('home.searchPlaceholder')}
              className="pl-10 pr-4 h-12 text-sm"
              defaultValue={searchQuery}
              onChange={(e) => handleSearchChange(e.target.value)}
              onFocus={() => {
                setIsSearchFocused(true);
                setShowSuggestions(true);
              }}
              onBlur={() => {
                setIsSearchFocused(false);
                // Delay hiding suggestions to allow clicking on them
                setTimeout(() => setShowSuggestions(false), 200);
              }}
            />
          </div>

          {/* Suggestions Toggle */}
          <Popover open={showSuggestions} onOpenChange={setShowSuggestions}>
            <PopoverTrigger asChild>
              <Button variant="outline" size="icon" className="h-12 w-12">
                <Filter className="h-4 w-4" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-96 p-0" align="end">
              <SearchSuggestions 
                onSuggestionClick={handleSuggestionClick}
              />
            </PopoverContent>
          </Popover>
        </div>

        {/* Quick Search History (when focused) */}
        {isSearchFocused && searchHistory.length > 0 && (
          <Card className="absolute top-full left-0 right-0 z-50 mt-1 shadow-lg">
            <CardContent className="p-3">
              <div className="flex items-center gap-2 mb-2">
                <Clock className="h-3 w-3 text-gray-500" />
                <span className="text-xs text-gray-600 font-medium">Recent Searches</span>
              </div>
              <div className="flex flex-wrap gap-1">
                {searchHistory.slice(0, 5).map((item, index) => (
                  <Badge
                    key={index}
                    variant="outline"
                    className="cursor-pointer hover:bg-gray-50 text-xs"
                    onClick={() => handleSuggestionClick(item)}
                  >
                    {item}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Active Filters */}
      {(Object.keys(activeFilters).length > 0 || searchQuery) && (
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-xs text-gray-600 font-medium">Active filters:</span>
          {searchQuery && (
            <Badge variant="default" className="text-xs">
              <Search className="h-3 w-3 mr-1" />
              "{searchQuery}"
            </Badge>
          )}
          {getFilterBadges()}
          {(Object.keys(activeFilters).length > 0 || searchQuery) && (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={clearAllFilters}
              className="text-xs h-6 px-2"
            >
              Clear all
            </Button>
          )}
        </div>
      )}

      {/* Search Stats */}
      {searchQuery && (
        <div className="flex items-center gap-4 text-xs text-gray-500">
          <div className="flex items-center gap-1">
            <TrendingUp className="h-3 w-3" />
            <span>Popular search</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            <span>Last searched 2 days ago</span>
          </div>
        </div>
      )}
    </div>
  );
}