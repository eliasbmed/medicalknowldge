import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useLanguage } from "@/hooks/use-language";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface AddFactModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function AddFactModal({
  open,
  onOpenChange,
}: AddFactModalProps) {
  const { t } = useLanguage();
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    title: "",
    details: "",
    category: "",
  });

  const submitFactMutation = useMutation({
    mutationFn: async (factData: any) => {
      const response = await apiRequest("POST", "/api/facts", factData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: t('addFact.success'),
      });
      onOpenChange(false);
      setFormData({ title: "", details: "", category: "" });
    },
    onError: (error: any) => {
      toast({
        title: t('common.error'),
        description: error.message || "Failed to submit fact",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.title && formData.details && formData.category) {
      submitFactMutation.mutate(formData);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="modal-slide-in">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-gray-800">
            {t('addFact.title')}
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 mt-6">
          <Input
            placeholder={t('addFact.factTitle')}
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            required
          />
          
          <Textarea
            placeholder={t('addFact.details')}
            value={formData.details}
            onChange={(e) => setFormData({ ...formData, details: e.target.value })}
            rows={4}
            required
          />
          
          <Select
            value={formData.category}
            onValueChange={(value) => setFormData({ ...formData, category: value })}
          >
            <SelectTrigger>
              <SelectValue placeholder={t('addFact.selectCategory')} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="emergency">{t('categories.emergency')}</SelectItem>
              <SelectItem value="cardiology">{t('categories.cardiology')}</SelectItem>
              <SelectItem value="neurology">{t('categories.neurology')}</SelectItem>
              <SelectItem value="pediatrics">{t('categories.pediatrics')}</SelectItem>
              <SelectItem value="pharmacology">{t('categories.pharmacology')}</SelectItem>
              <SelectItem value="surgery">{t('categories.surgery')}</SelectItem>
              <SelectItem value="infection">{t('categories.infection')}</SelectItem>
              <SelectItem value="endocrinology">{t('categories.endocrinology')}</SelectItem>
            </SelectContent>
          </Select>
          
          <div className="flex space-x-3">
            <Button
              type="submit"
              disabled={submitFactMutation.isPending}
              className="flex-1 bg-blue-500 hover:bg-blue-600 text-white font-bold transition-colors duration-300"
            >
              {submitFactMutation.isPending ? t('common.loading') : t('addFact.submit')}
            </Button>
            <Button
              type="button"
              onClick={() => onOpenChange(false)}
              className="flex-1 bg-gray-500 hover:bg-gray-600 text-white font-bold transition-colors duration-300"
              variant="secondary"
            >
              {t('common.cancel')}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
