import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface GuestVoteModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  factId: number | null;
  voteType: 'agree' | 'disagree' | null;
}

export default function GuestVoteModal({ open, onOpenChange, factId, voteType }: GuestVoteModalProps) {
  const [guestRole, setGuestRole] = useState("");
  const [guestSpecialty, setGuestSpecialty] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const voteMutation = useMutation({
    mutationFn: async () => {
      if (!factId || !voteType) throw new Error("Missing vote data");
      
      const response = await apiRequest("POST", "/api/votes", {
        factId,
        voteType,
        guestRole,
        guestSpecialty,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Vote recorded!",
        description: "Thank you for your contribution",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/facts"] });
      onOpenChange(false);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to record vote",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = () => {
    if (!guestRole) {
      toast({
        title: "Role required",
        description: "Please select your medical role",
        variant: "destructive",
      });
      return;
    }
    voteMutation.mutate();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Vote as Guest</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label htmlFor="role">Your medical role *</Label>
            <Select value={guestRole} onValueChange={setGuestRole}>
              <SelectTrigger>
                <SelectValue placeholder="Select your role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="doctor">Doctor</SelectItem>
                <SelectItem value="nurse">Nurse</SelectItem>
                <SelectItem value="student">Medical Student</SelectItem>
                <SelectItem value="resident">Resident</SelectItem>
                <SelectItem value="other">Other Healthcare Professional</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="specialty">Specialty (optional)</Label>
            <Select value={guestSpecialty} onValueChange={setGuestSpecialty}>
              <SelectTrigger>
                <SelectValue placeholder="Select your specialty" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="emergency">Emergency Medicine</SelectItem>
                <SelectItem value="cardiology">Cardiology</SelectItem>
                <SelectItem value="surgery">Surgery</SelectItem>
                <SelectItem value="internal">Internal Medicine</SelectItem>
                <SelectItem value="pediatrics">Pediatrics</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex space-x-3">
            <Button onClick={() => onOpenChange(false)} variant="outline" className="flex-1">
              Cancel
            </Button>
            <Button 
              onClick={handleSubmit} 
              disabled={voteMutation.isPending}
              className="flex-1"
            >
              {voteMutation.isPending ? "Submitting..." : `Vote ${voteType}`}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}