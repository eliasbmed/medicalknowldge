import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface SignupModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  factId: number | null;
  voteType: 'agree' | 'disagree' | null;
}

export default function SignupModal({ open, onOpenChange }: SignupModalProps) {
  const handleSignup = () => {
    window.location.href = '/api/login';
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Join MedFacts</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <p className="text-gray-600">Sign up to unlock all features:</p>
          <ul className="list-disc list-inside space-y-2 text-sm text-gray-600">
            <li>Track your voting history</li>
            <li>Bookmark important facts</li>
            <li>Participate in quizzes</li>
            <li>Build your reputation</li>
            <li>Access personalized content</li>
          </ul>
          <div className="flex space-x-3">
            <Button onClick={() => onOpenChange(false)} variant="outline" className="flex-1">
              Cancel
            </Button>
            <Button onClick={handleSignup} className="flex-1">
              Sign Up
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}