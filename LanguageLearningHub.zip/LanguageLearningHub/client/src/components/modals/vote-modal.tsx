import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/hooks/use-language";

interface VoteModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSignup: () => void;
  onGuestVote: () => void;
}

export default function VoteModal({ open, onOpenChange, onSignup, onGuestVote }: VoteModalProps) {
  const { t } = useLanguage();

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Vote on this fact</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <p className="text-gray-600">To vote on medical facts, you can either:</p>
          <div className="space-y-3">
            <Button onClick={onSignup} className="w-full">
              Sign up for full features
            </Button>
            <Button onClick={onGuestVote} variant="outline" className="w-full">
              Vote as guest
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}