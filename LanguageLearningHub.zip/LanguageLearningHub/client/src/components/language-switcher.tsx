import { useLanguage, type Language } from "@/hooks/use-language";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Globe } from "lucide-react";

// Simple SVG flag components
function USFlag({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 60 30" className={className}>
      <rect width="60" height="30" fill="#b22234"/>
      <rect width="60" height="2" y="2" fill="#fff"/>
      <rect width="60" height="2" y="6" fill="#fff"/>
      <rect width="60" height="2" y="10" fill="#fff"/>
      <rect width="60" height="2" y="14" fill="#fff"/>
      <rect width="60" height="2" y="18" fill="#fff"/>
      <rect width="60" height="2" y="22" fill="#fff"/>
      <rect width="60" height="2" y="26" fill="#fff"/>
      <rect width="24" height="15" fill="#3c3b6e"/>
      <circle cx="4" cy="3" r="0.8" fill="#fff"/>
      <circle cx="8" cy="3" r="0.8" fill="#fff"/>
      <circle cx="12" cy="3" r="0.8" fill="#fff"/>
      <circle cx="16" cy="3" r="0.8" fill="#fff"/>
      <circle cx="20" cy="3" r="0.8" fill="#fff"/>
      <circle cx="6" cy="6" r="0.8" fill="#fff"/>
      <circle cx="10" cy="6" r="0.8" fill="#fff"/>
      <circle cx="14" cy="6" r="0.8" fill="#fff"/>
      <circle cx="18" cy="6" r="0.8" fill="#fff"/>
      <circle cx="4" cy="9" r="0.8" fill="#fff"/>
      <circle cx="8" cy="9" r="0.8" fill="#fff"/>
      <circle cx="12" cy="9" r="0.8" fill="#fff"/>
      <circle cx="16" cy="9" r="0.8" fill="#fff"/>
      <circle cx="20" cy="9" r="0.8" fill="#fff"/>
      <circle cx="6" cy="12" r="0.8" fill="#fff"/>
      <circle cx="10" cy="12" r="0.8" fill="#fff"/>
      <circle cx="14" cy="12" r="0.8" fill="#fff"/>
      <circle cx="18" cy="12" r="0.8" fill="#fff"/>
    </svg>
  );
}

function AlgerianFlag({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 60 30" className={className}>
      <rect width="30" height="30" fill="#006233"/>
      <rect x="30" width="30" height="30" fill="#ffffff"/>
      <circle cx="30" cy="15" r="6" fill="#d21034"/>
      <path d="M28,15 L30,12 L32,15 L30,18 Z" fill="#ffffff"/>
      <circle cx="32" cy="13" r="1.5" fill="#d21034"/>
    </svg>
  );
}

function SpanishFlag({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 60 30" className={className}>
      <rect width="60" height="7.5" fill="#aa151b"/>
      <rect width="60" height="15" y="7.5" fill="#f1bf00"/>
      <rect width="60" height="7.5" y="22.5" fill="#aa151b"/>
      <rect x="15" y="12" width="8" height="6" fill="#aa151b" rx="1"/>
    </svg>
  );
}

export default function LanguageSwitcher() {
  const { language, setLanguage } = useLanguage();

  const flags = [
    {
      code: 'en' as Language,
      label: 'English',
      flag: USFlag
    },
    {
      code: 'fr' as Language,
      label: 'Français',
      flag: AlgerianFlag
    },
    {
      code: 'es' as Language,
      label: 'Español',
      flag: SpanishFlag
    }
  ];

  const currentFlag = flags.find(flag => flag.code === language);
  const CurrentFlagComponent = currentFlag?.flag;

  const languageOptions = [
    { code: 'en', label: 'EN' },
    { code: 'fr', label: 'FR' },
    { code: 'es', label: 'ES' }
  ];

  return (
    <div className="fixed top-4 right-4 z-50">
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button className="flex items-center gap-2 px-3 py-2 rounded-full bg-white/90 backdrop-blur-md border border-white/20 hover:bg-white/95 transition-all duration-300 shadow-lg">
            <Globe className="w-4 h-4 text-gray-600" />
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent 
          align="end" 
          className="bg-white/95 backdrop-blur-md border-white/20 shadow-xl min-w-[100px]"
        >
          {languageOptions.map((option) => (
            <DropdownMenuItem
              key={option.code}
              onClick={() => setLanguage(option.code as Language)}
              className={`cursor-pointer px-3 py-2 hover:bg-blue-50 transition-colors ${
                language === option.code ? 'bg-blue-100 text-blue-700 font-semibold' : ''
              }`}
            >
              {option.label}
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
