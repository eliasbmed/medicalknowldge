import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { 
  Brain, 
  TrendingUp, 
  AlertCircle, 
  CheckCircle, 
  Clock,
  Users,
  BookOpen,
  Lightbulb,
  Target
} from 'lucide-react';
import { useLanguage } from '@/hooks/use-language';

interface MedicalInsightsProps {
  className?: string;
}

export function MedicalInsights({ className }: MedicalInsightsProps) {
  const { t } = useLanguage();

  const insights = [
    {
      type: 'trending',
      icon: TrendingUp,
      title: 'Trending Topic',
      content: 'Cardiac arrest protocols are being heavily discussed this week',
      category: 'emergency',
      urgency: 'high',
      timeframe: '72% increase in views'
    },
    {
      type: 'knowledge_gap',
      icon: AlertCircle,
      title: 'Knowledge Gap Identified',
      content: 'Consider reviewing antibiotic resistance patterns',
      category: 'internal',
      urgency: 'medium',
      timeframe: 'Based on recent quiz results'
    },
    {
      type: 'achievement',
      icon: CheckCircle,
      title: 'Learning Milestone',
      content: 'You\'ve mastered 85% of emergency medicine concepts',
      category: 'emergency',
      urgency: 'positive',
      timeframe: 'Keep up the great work!'
    },
    {
      type: 'recommendation',
      icon: Lightbulb,
      title: 'Personalized Recommendation',
      content: 'Explore pediatric dosing guidelines next',
      category: 'pediatrics',
      urgency: 'low',
      timeframe: 'Recommended for you'
    }
  ];

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'high': return 'border-l-red-500 bg-red-50';
      case 'medium': return 'border-l-yellow-500 bg-yellow-50';
      case 'positive': return 'border-l-green-500 bg-green-50';
      default: return 'border-l-blue-500 bg-blue-50';
    }
  };

  const getCategoryIcon = (category: string) => {
    const icons = {
      emergency: AlertCircle,
      internal: Brain,
      pediatrics: Users,
      cardiology: Target
    };
    return icons[category as keyof typeof icons] || BookOpen;
  };

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Brain className="h-5 w-5 text-purple-600" />
          Medical Insights
        </CardTitle>
        <CardDescription>
          AI-powered insights based on your learning patterns and current medical trends
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {insights.map((insight, index) => {
          const IconComponent = insight.icon;
          const CategoryIcon = getCategoryIcon(insight.category);
          
          return (
            <div 
              key={index}
              className={`p-4 border-l-4 rounded-r-lg ${getUrgencyColor(insight.urgency)}`}
            >
              <div className="flex items-start gap-3">
                <div className="p-2 bg-white rounded-full shadow-sm">
                  <IconComponent className="h-4 w-4 text-gray-600" />
                </div>
                <div className="flex-1 space-y-2">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium text-gray-900">{insight.title}</h4>
                    <Badge variant="outline" className="text-xs">
                      <CategoryIcon className="h-3 w-3 mr-1" />
                      {insight.category}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-700">{insight.content}</p>
                  <div className="flex items-center justify-between">
                    <p className="text-xs text-gray-500">{insight.timeframe}</p>
                    <Button size="sm" variant="ghost" className="text-xs h-6">
                      Learn More
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}

        {/* Quick Actions */}
        <div className="pt-4 border-t">
          <div className="grid grid-cols-2 gap-3">
            <Button variant="outline" size="sm" className="text-xs">
              <Target className="h-3 w-3 mr-1" />
              Set Learning Goals
            </Button>
            <Button variant="outline" size="sm" className="text-xs">
              <Brain className="h-3 w-3 mr-1" />
              Take Assessment
            </Button>
          </div>
        </div>

        {/* Learning Progress Indicator */}
        <div className="bg-white p-4 rounded-lg border">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-700">Weekly Learning Goal</span>
            <span className="text-sm text-gray-500">12/15 facts</span>
          </div>
          <Progress value={80} className="h-2" />
          <p className="text-xs text-gray-500 mt-2">
            3 more facts to complete your weekly goal
          </p>
        </div>
      </CardContent>
    </Card>
  );
}