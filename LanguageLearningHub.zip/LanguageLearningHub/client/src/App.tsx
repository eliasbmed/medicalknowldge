import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import Home from "@/pages/home";
import EnhancedHome from "@/pages/enhanced-home";
import Dashboard from "@/pages/dashboard";
import QuizMode from "@/pages/quiz/quiz-mode";
import Leaderboard from "@/pages/leaderboard/leaderboard";
import NotFound from "@/pages/not-found";
import { LanguageProvider } from "@/hooks/use-language";

function Router() {
  return (
    <Switch>
      <Route path="/" component={EnhancedHome} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/quiz" component={QuizMode} />
      <Route path="/leaderboard" component={Leaderboard} />
      <Route path="/simple" component={Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </LanguageProvider>
    </QueryClientProvider>
  );
}

export default App;
